@component('admin.section.content',['title'=>' مدیریت بارکد'])
@slot('bread')
<li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
<li class="breadcrumb-item">مدیریت بارکد</li>
@endslot


<div class="row">
    <div class="col-md-12">
        <div class="row">


            <div class="col-md-6">


                <div class="card">
                    <div class="card-header no-border">
                        <div class="d-flex justify-content-between">
                            <h3 class="card-title">
                                اقدامات بارکد
                            </h3>
                            <a href="javascript:void(0);"> {{$barcode->code}}</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex">
                            <p class="d-flex flex-column">
                                <span class="text-bold text-lg"> آخرین وضعیت </span>
                                <span>
                                    @if (!$barcode->customer)
                                    فروش نرفته
                                    -داخل انبار
                                    @else
                                    @switch($barcode->store)
                                    @case(null)
                                    تعیین نشده
                                    @break
                                    @case(1)
                                    داخل انبار
                                    @break
                                    @case(0)
                                    خارج
                                    @break
                                    @endswitch
                                    @endif
                                </span>
                            </p>
                            {{-- <p class="mr-auto d-flex flex-column text-right">
                                <span class="text-success">
                                    <i class="fa fa-arrow-up"></i> ۱۲.۵%
                                </span>
                                <span class="text-muted">از هفته گذشته</span>
                            </p> --}}
                        </div>
                        @php
                        $repair =$barcode->repairs()->latest()->first();
                        @endphp

                        @if (!$barcode->customer)
                        <a href="{{route('barcode.edit',$barcode->id)}}" class="btn btn-success">فروش</a>
                        @else

                          @if (($barcode->last_id) && $barcode->last_id != auth()->user()->id)
                          <a href="{{route('transfer.create',['barcode'=>$barcode->id])}}" class="btn btn-danger">انتقال</a>
                           @endif
                        @switch($barcode->store)
                        @case(null)
                        @if ($repair)
                        <a href="{{route('repair.edit',$repair->id)}}" class="btn btn-success">  تحویل</a>
                        @else
                        <a href="{{route('repair.index',['code'=>$barcode->id])}}" class="btn btn-success">ثبت خرابی</a>
                        @endif
                        @break

                        @case(1)
                        @if (  $repair)
                        <a href="{{route('repair.edit',$repair->id)}}" class="btn btn-success">  تحویل</a>
                        @endif
                        @break

                        @case(0)
                        <a href="{{route('repair.index',['code'=>$barcode->id])}}" class="btn btn-success">ثبت خرابی</a>
                        @break
                        @endswitch

                        @endif


                    </div>
                </div>
            </div>
            @include('admin.barcode.record',['barcode'=>$barcode])

        </div>
    </div>
</div>


@endcomponent
