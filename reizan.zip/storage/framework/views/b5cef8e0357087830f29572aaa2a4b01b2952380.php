<script>
    function onloadCallback() {
        <?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            document.getElementById('<?php echo e($id); ?>').classList.add("g-recaptcha");
        let client<?php echo e($id); ?> =  grecaptcha.render('<?php echo e($id); ?>', {
            'sitekey': '<?php echo e($publicKey); ?>',
            'theme': '<?php echo e($theme); ?>',
            'badge': '<?php echo e($badge); ?>',
            'size': '<?php echo e($size); ?>',
            'hl': '<?php echo e($language); ?>'
        });

        <?php if($size==='invisible'): ?>
        grecaptcha.ready(function () {
            grecaptcha.execute(client<?php echo e($id); ?>);
        });
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    }
</script>
<script src="https://www.google.com/recaptcha/api.js?render=explicit&onload=onloadCallback" defer async></script>
<?php /**PATH G:\laravelProject\reizan\vendor\timehunter\laravel-google-recaptcha-v2\src\Providers/../../resources/views/googlerecaptchav2/template.blade.php ENDPATH**/ ?>