<?php $__env->startComponent('admin.section.content',['title'=>'فرم جستو جو  ']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">فرم جستو جو   </li>
    <?php $__env->endSlot(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  فرم جستو جو     </h3>
                            <div class="card-tools">



                            </div>
                            <div class="card-tools">

                            </div>

                            <div class="card card-success">
                                <div class="card-header">
                                    <h3 class="card-title">اطلاعات جست و جو  </h3>
                                </div>
                                <form action="<?php echo e(route('admin.form')); ?>" method="get" autocomplete="off">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('get'); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="productpart">محصول  </label>
                                                <select class="form-control" name="product_id" id="productpart">
                                                    <option value="">یک مورد را انتخاب کنید</option>
                                                    <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option  <?php echo e(request('product_id')==$product->id?'selected':''); ?> value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-4">

                                            <div class="form-group">
                                                <label for="part">       قطعات</label>
                                                <select class="form-control select2"  name="part"   id="part">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = \App\Models\Part::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(request('part')==$part->id?'selected':''); ?> value="<?php echo e($part->id); ?>"><?php echo e($part->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-4">

                                            <div class="form-group">
                                                <label for="part">       Data Logger</label>
                                                <select class="form-control select2"  name="dls1[]"  multiple  id="dls">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = \App\Models\Dl::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(in_array($dls->id,request('dls1',[]))?'selected':''); ?> value="<?php echo e($dls->id); ?>"><?php echo e($dls->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">

                                            <div class="row" id="dls_section">
                                                    <?php if(request('dls')): ?>
                                                    <?php $__currentLoopData = request('dls'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ke=> $va): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    

                                                        <div class="col-lg-6">
                                                            <div class="row">
                                                                <div class="col-2">
                                                                    <h5>
                                                                        <?php echo e(\App\Models\Dl::find($ke)->name); ?>

                                                                    </h5>
                                                                </div>
                                                                <div class="col-4">
                                                                    <div class="form-group">
                                                                        <label for="">بیشینه</label>
                                                                        <input type="number" name="dls[<?php echo e($ke); ?>][max]" class="form-control" value="<?php echo e($va['max']); ?>" placeholder="max">
                                                                    </div>
                                                                </div>
                                                                <div class="col-4">
                                                                    <div class="form-group">
                                                                        <label for="">کمینه </label>
                                                                        <input type="number" name="dls[<?php echo e($ke); ?>][min]" class="form-control" value="<?php echo e($va['min']); ?>" placeholder="min">
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <div class=" form-group">
                                                                        <span style="position:relative; top: 37px" data-val="<?php echo e($ke); ?>" class="btn btn-warning remove_r form-control" data-cl="ch<?php echo e($ke); ?>"  data-ids="${last}" data-id="dls[${i}][status]">حذف</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>

                                                <?php endif; ?>


                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="version">  ورژن  </label>
                                                <select class="form-control" name="version_id" id="version">
                                                    <option value="">یک مورد را انتخاب کنید</option>
                                                    <?php $__currentLoopData = \App\Models\Version::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(request('version_id')==$version->id?'selected':''); ?> value="<?php echo e($version->id); ?>"><?php echo e($version->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                        </div>

                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="color">رنگ  </label>
                                                <select class="form-control select2" name="color[]" multiple id="color">
                                                    <?php
                                                    $colores=array();
                                                     if (request('color')){
                                                         $colores=request('color');
                                                     }
                                                    ?>
                                                    <option value="">یک مورد را انتخاب کنید</option>
                                                    <?php $__currentLoopData = \App\Models\Color::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option  <?php echo e(in_array($color->id,$colores)?'selected':''); ?> value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-4"> 
                                            <div class="form-group">
                                                <label for="color">نحوه جستو جو  </label>
                                                <select class="form-control  " name="typesearch"  id="typesearch">
                                                    <option selected value="">همه دستگاه ها</option>
                                                    <option <?php echo e(request('typesearch')=='stock'?'selected':''); ?> value="stock">دارای موجودی</option>
                                                    <option <?php echo e(request('typesearch')=='failure'?'selected':''); ?> value="failure">دارای خرابی</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="produce_from">  تاریخ تولید از</label>
                                                <input type="text" name="produce_from" value="<?php echo e(request('produce_from')); ?>" class="form-control persian3" id="produce_from" placehrequest()er="تاریخ تولیداز را وارد کنید">
                                            </div>

                                        </div>

                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="produce_till">  تاریخ تولید تا</label>
                                                <input type="text" name="produce_till" value="<?php echo e(request('produce_till')); ?>" class="form-control persian3" id="produce_till" placehrequest()er="تاریخ تولید تا را وارد کنید">
                                            </div>

                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="deliver_from">  تاریخ خروج از</label>
                                                <input type="text" name="deliver_from" value="<?php echo e(request('deliver_from')); ?>" class="form-control persian3" id="deliver_from" placehrequest()er="تاریخ خروج از را وارد کنید">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="deliver_till">  تاریخ خروج تا</label>
                                                <input type="text" name="deliver_till" value="<?php echo e(request('deliver_till')); ?>" class="form-control persian3" id="deliver_till" placehrequest()er="تاریخ خروج تا را وارد کنید">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="color">مشتری  </label>
                                                <select class="form-control" name="customer_id" id="customer">
                                                    <option value="" >یک مورد را انتخاب کنید</option>
                                                    <?php $__currentLoopData = \App\Models\User::whereLevel('customer')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option  <?php echo e(request('customer_id')==$customer->id?'selected':''); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> <?php echo e($customer->family); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="ostan">       استان</label>
                                                <select class="form-control" name="ostan_id" id="ostan">
                                                    <option value="" >استان را انتخاب کنید </option>
                                                    <?php $__currentLoopData = \App\Models\Ostan::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ostan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(request('ostan_id')==$ostan->id?'selected':''); ?> value="<?php echo e($ostan->id); ?>"><?php echo e($ostan->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>




                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('dewater')==1?'checked':''); ?> name="dewater" id="dewater" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="dewater">آبخوردگی
                                                    </label>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('dehit')==1?'checked':''); ?> name="dehit" id="dehit" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="dehit">ضربه خوردگی
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('debar')==1?'checked':''); ?> name="debar" id="debar" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="debar">اضافه بار
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('detemp')==1?'checked':''); ?> name="detemp" id="detemp" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="detemp">اضافه حرارت محیط
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('deopen')==1?'checked':''); ?> name="deopen" id="deopen" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="deopen">    باز شدن پلمپ
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('demulti')==1?'checked':''); ?> name="demulti" id="demulti" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="demulti">
                                                        دستکاری مولتی ترن
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" <?php echo e(request('wage')==1?'checked':''); ?> name="wage" id="wage" class="form-check-inline" value="1">
                                                    <label class="form-check-inline" for="wage">  دارای هزینه حمل
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label class="form-check-inline" for="rcount">دفعات خرابی
                                                </label>
                                                <input type="number" value="<?php echo e(request('rcount')); ?>" name="rcount" id="rcount" class="form-check-inline" >
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <label for="submit" id="submit">نتیجه:
                                            <?php echo e($barcodes->total()); ?>

                                                عدد
                                            </label>
                                            <input type="submit" id="submit" value="جستو جو" class="btn form-control btn-danger">
                                        </div>
                                        <div class="col-lg-4">
                                            <label for="submit" id="submit">دوباره:
                                            </label>
                                            <a href="<?php echo e(route('admin.form')); ?>" class="btn btn-warning form-control">ریست کردن</a>

                                        </div>
                                    </div>
                                </div>
                                </form>

                                <!-- /.card-body -->
                            </div>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>کد </th>
                                    <th>محصول </th>
                                    <th>تاریخ تولید </th>
                                    <th>تاریخ خروج </th>
                                    <th>  ورژن </th>
                                    <th>  رنگ </th>
                                    <th>  مشتری </th>
                                    <th>  اپراتور </th>
                                    <th>  توضیحات </th>
                                    <th>  اقدامات </th>
                                </tr>
                                <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <a class="text-success" href="<?php echo e(route('barcode.show',$barcode->id)); ?>"><?php echo e($barcode->code); ?></a>
                                        </td>

                                        <td><?php echo e(isset($barcode->product)?$barcode->product->name:''); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)); ?></td>
                                        <td>  <?php echo e(implode(', ',$barcode->colores->pluck('name')->toArray())); ?></td>
                                        <td><?php echo e(isset($barcode->version)?$barcode->version->name:'----'); ?></td>
                                        <td><?php echo e(isset($barcode->customer)?$barcode->customer->name.' '.$barcode->customer->family:'----'); ?></td>
                                        <td><?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($operator->name); ?>

                                                <?php echo e($operator->family); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($barcode->info); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is_admin')): ?>
                                                <a class="btn btn-outline-secondary" href="<?php echo e(route('barcode.show',$barcode->id)); ?>">مشاهده</a>
                                            <?php endif; ?>






                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">

                            <div class="pagi">
                                <?php echo e($barcodes->appends(Request::all())->links('admin.pagination')); ?>

                            </div>

                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>

    <?php $__env->slot('script'); ?>
    <script>

        let createNewDls=({obj_a,id,last})=>{

            var list;
            var i=id;

            `
            ${
                $.each(obj_a, function(index, value){
                    console.log(858585)
                    console.log(last)
                    list =  `


                       <div class="col-lg-6  col-md-12 part_op" id="dls-${last}">
                            <div class="row">
                                <div class="col-2">
                                    <h5>
                                        ${value}
                                    </h5>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="">بیشینه</label>
                                        <input type="number" name="dls[${last}][max]" class="form-control" value="" placeholder="max">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="">کمینه </label>
                                        <input type="number" name="dls[${last}][min]" class="form-control" value="" placeholder="min">
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class=" form-group">
                                        <span style="position:relative; top: 37px" data-val="${last}" class="btn btn-warning remove_r form-control" data-cl="ch${last}"  data-ids="${last}" data-id="dls[${i}][status]">حذف</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                      `
                    // i++;

                })
            }

        `
            return list;
        }

        // $("select").on("select2:unselect", function (e) {
        //     var value=   e.params.data.id;
        //     alert(value);
        // });
        $('#dls').on("select2:unselect", function(e){
            var el=$(this)
            let last=e.params.data.id
            let ids='dls-'+last
            // var elem = document.querySelector('#'+id);
            // elem.style.display = 'none';
            $('.part_op').each(function() {
                let el=$(this)
                let id=el.attr('id')
                if (ids==id){
                    el.remove()
                }
                console.log(323223)
                console.log(id)
            })
        }).trigger('change');
        $('#dls').on('select2:select', function(e) {
            // $(document.body).on("change","#parts",function(e){

            let parts=$('#dls').val()
            let last=e.params.data.id
            var obj_a = {};
            obj_a[last]= $('#dls option[value='+last+']').text();

            // parts.forEach(function(val, i) {
            //    var text= $('#parts option[value='+val+']').text();
            //     obj_a[val] = text;
            //
            // });

            let ps=$('#dls_section')
            let id= ps.children().length
            // ps.append(
            // '<br>'
            // )
            ps.append(
                createNewDls({
                    obj_a,id,last
                })
            )
            // $('.attr_select2').select2({tags:true})
        });
        $(document).on('click', '.remove_r', function (event) {
            var el = $(this);
            var ids = el.data('ids');
            var val = el.data('val');
            var id = el.data('id');
            var cl = el.data('cl');
            $('#dls option[value='+val+']').prop("selected", false)     // deselect the option
                .parent().trigger("change");
            $('#' + 'dls-'+val).remove();
            $('.' + cl).attr('checked', false);
            $('.' + cl).prop('checked', false); // $('input[name='+id+']').prop('checked', false);
        });
        // if ($('#parts').length){
        //     let parts=$('#parts').val()
        //     var obj_a = {};
        //     parts.forEach(function(val, i) {
        //         var text= $('#parts option[value='+val+']').text();
        //         obj_a[val] = text;
        //
        //     });
        //     let ps=$('#part_section')
        //     let id= ps.children().length
        //     ps.html(
        //         '<br>'
        //     )
        //     ps.html(
        //         createNewDls({
        //             obj_a ,
        //             id
        //         })
        //     )
        //
        // }

    </script>
    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/report/form.blade.php ENDPATH**/ ?>