<?php $__env->startComponent('admin.section.content',['title'=>'لیست   انتقال و موجودی']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست  انتقال و موجودی  </li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست    موجودی  </h3>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>بارکد </th>
                                    <th>وضعیت فروش </th>
                                    <th>  تاریخ خروج </th>
                                    <th>  تاریخ خروج </th>

                                </tr>
                                <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php echo e($barcode->code); ?>

                                        </td>
                                        <td>
                                           <?php echo e($barcode->customer_id?$barcode->customer->name.' '.$barcode->customer->family: 'فروش نرفته'); ?>

                                        </td>

                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->created_at)); ?></td>

                                        <td>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست    انتقال  </h3>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>بارکد </th>
                                    <th>مبدا </th>
                                    <th>توضیحات مبدا </th>
                                    <th>مقصد </th>
                                    <th>توضیحات مقصد </th>
                                    <th>  وضعیت </th>

                                    <th>تاریخ ثبت  </th>
                                    <th>تاریخ بررسی  </th>

                                </tr>
                                <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php echo e($transfer->barcode->code); ?>

                                        </td>
                                        <td>
                                            <?php echo e($transfer->from->name); ?>

                                            <?php echo e($transfer->from->family); ?>

                                        </td>
                                        <td>
                                            <?php echo e($transfer->info_from); ?>

                                        </td>
                                        <td>
                                            <?php echo e($transfer->to->name); ?>

                                            <?php echo e($transfer->to->family); ?>

                                        </td>
                                        <td>
                                            <?php echo e($transfer->info_to); ?>

                                        </td>
                                        <td>
                                            <?php switch($transfer->status):
                                                case (null): ?>
                                            در دست بررسی
                                            <?php break; ?>
                                                <?php case (1): ?>
                                            تایید شده
                                            <?php break; ?>
                                                <?php case (1): ?>
                                              رد شده
                                            <?php break; ?>

                                                <?php default: ?>

                                            <?php endswitch; ?>
                                        </td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($transfer->created_at)); ?></td>
                                        <td>
                                            <?php if($transfer->time): ?>
                                            <?php echo e(\Morilog\Jalali\Jalalian::forge($transfer->time)); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>

                                           <?php if(is_null($transfer->status)): ?>
                                           <?php if($transfer->to_id==auth()->user()->id ): ?>
                                           <a class="btn btn-outline-primary" href="<?php echo e(route('transfer.edit',$transfer->id)); ?>">تایید</a>


                                           <?php endif; ?>
                                           <?php if($transfer->from_id==auth()->user()->id ): ?>
                                           <form action="<?php echo e(route('transfer.destroy',$transfer->id)); ?>" style="display: inline-block" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="submit"  onclick="return confirm('Are you sure?')" value="حذف" class="btn btn-danger">
                                              </form>


                                           <?php endif; ?>


                                           <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->




                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/transfer/all.blade.php ENDPATH**/ ?>