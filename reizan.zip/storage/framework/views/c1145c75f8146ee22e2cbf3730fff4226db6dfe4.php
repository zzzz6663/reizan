<div id="header" class="rows">
    <div>

        <div class="container">
            <div class="row">

                <!-- Start Logo -->
                <div class="col-lg-2 col-md-3">
                    <div>
                        <div id="logo">
                            <a href="<?php echo e(route('login')); ?>">
                                 <img src="/home/images/logo.png" alt="">

                            </a>
                        </div>
                    </div>
                </div>
                <!-- End Logo -->

                <div class="col-lg-7 col-md-4">
                    <div>

                        <div id="mobile-menu">
									<span>
										<svg xmlns="http://www.w3.org/2000/svg" width="51" height="50" viewBox="0 0 51 50">
										  <g transform="translate(-337 -15)">
										    <rect width="51" height="50" transform="translate(337 15)" fill="#fff"></rect>
										    <path d="M4.517,5.834H26.9a1.339,1.339,0,0,0,1.417-1.417A1.339,1.339,0,0,0,26.9,3H4.517A1.339,1.339,0,0,0,3.1,4.417,1.42,1.42,0,0,0,4.517,5.834Zm22.385,8.5H4.517A1.339,1.339,0,0,0,3.1,15.751a1.339,1.339,0,0,0,1.417,1.417H26.9a1.339,1.339,0,0,0,1.417-1.417A1.42,1.42,0,0,0,26.9,14.334Zm0,11.334H4.517a1.417,1.417,0,0,0,0,2.834H26.9a1.339,1.339,0,0,0,1.417-1.417A1.42,1.42,0,0,0,26.9,25.668Z" transform="translate(346.682 24.249)" fill="currentColor"></path>
										  </g>
										</svg>

									</span>
                        </div>

                        <div id="mainmenu">
                            <ul>
                                <li><a href="<?php echo e(route('login')); ?>">    صفحه اصلی</a></li>
                                <li class="has-child">
                                    <a href="#">خدمات</a>
                                    <ul>
                                        <?php $__currentLoopData = \App\Models\Service::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('home.services',$service->id)); ?>"><?php echo e($service->title); ?>  </a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <li class="mega has-child">
                                    <a href="#">محصولات</a>
                                    <ul class="mega-container" style="min-height: 20px;">
                                        <?php $__currentLoopData = \App\Models\Cat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li  ><a href="#"><?php echo e($cat->name); ?></a>
                                                <ul class="mega-submenu">
                                                    <li>

                                                        <ul>
                                                            <?php $__currentLoopData = $cat->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a href="<?php echo e(route('home.produce',$product->id)); ?>"> <?php echo e($product->name); ?></a></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </li>

                                                </ul>

                                            </li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('home.agency')); ?>">نمایندگی ها</a>
                                </li>
                                <li><a href="<?php echo e(route('home.contact')); ?>">تماس با ما</a></li>
                                <li><a href="<?php echo e(route('home.about')); ?>">    درباره ما</a></li>

                            </ul>
                        </div>

                    </div>
                </div>

                <!-- Start Buttons -->
                <div class="col-lg-3 col-md-8">
                    <div>

                        <a href="<?php echo e(route('home.check')); ?>" class="garanty">
									<span class="icon">
										<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M11.9531 16.3125C11.4353 16.3125 11.0156 16.7322 11.0156 17.25V21.2344C11.0156 21.7522 11.4353 22.1719 11.9531 22.1719C12.4709 22.1719 12.8906 21.7522 12.8906 21.2344V17.25C12.8906 16.7322 12.4709 16.3125 11.9531 16.3125Z" fill="white"></path>
											<path d="M0.9375 5.625C1.45528 5.625 1.875 5.20528 1.875 4.6875V1.875H4.6875C5.20528 1.875 5.625 1.45528 5.625 0.9375C5.625 0.419719 5.20528 0 4.6875 0H0.9375C0.419719 0 0 0.419719 0 0.9375V4.6875C0 5.20528 0.419719 5.625 0.9375 5.625Z" fill="white"></path>
											<path d="M4.73438 16.3125C4.21659 16.3125 3.79688 16.7322 3.79688 17.25V18.8906C3.79688 19.4084 4.21659 19.8281 4.73438 19.8281C5.25216 19.8281 5.67188 19.4084 5.67188 18.8906V17.25C5.67188 16.7322 5.25216 16.3125 4.73438 16.3125Z" fill="white"></path>
											<path d="M4.6875 22.125H1.875V19.3125C1.875 18.7947 1.45528 18.375 0.9375 18.375C0.419719 18.375 0 18.7947 0 19.3125V23.0625C0 23.5803 0.419719 24 0.9375 24H4.6875C5.20528 24 5.625 23.5803 5.625 23.0625C5.625 22.5447 5.20528 22.125 4.6875 22.125Z" fill="white"></path>
											<path d="M8.34375 16.3125C7.82597 16.3125 7.40625 16.7322 7.40625 17.25V18.8906C7.40625 19.4084 7.82597 19.8281 8.34375 19.8281C8.86153 19.8281 9.28125 19.4084 9.28125 18.8906V17.25C9.28125 16.7322 8.86153 16.3125 8.34375 16.3125Z" fill="white"></path>
											<path d="M23.0625 0H19.3125C18.7947 0 18.375 0.419719 18.375 0.9375C18.375 1.45528 18.7947 1.875 19.3125 1.875H22.125V4.6875C22.125 5.20528 22.5447 5.625 23.0625 5.625C23.5803 5.625 24 5.20528 24 4.6875V0.9375C24 0.419719 23.5803 0 23.0625 0Z" fill="white"></path>
											<path d="M15.7031 16.3125C15.1853 16.3125 14.7656 16.7322 14.7656 17.25V18.8906C14.7656 19.4084 15.1853 19.8281 15.7031 19.8281C16.2209 19.8281 16.6406 19.4084 16.6406 18.8906V17.25C16.6406 16.7322 16.2209 16.3125 15.7031 16.3125Z" fill="white"></path>
											<path d="M23.0625 13.0312H20.3438V4.6875C20.3438 4.16972 19.924 3.75 19.4062 3.75C18.8885 3.75 18.4688 4.16972 18.4688 4.6875V13.0312H16.6406V4.6875C16.6406 4.16972 16.2209 3.75 15.7031 3.75C15.1853 3.75 14.7656 4.16972 14.7656 4.6875V13.0312H12.8906V4.6875C12.8906 4.16972 12.4709 3.75 11.9531 3.75C11.4353 3.75 11.0156 4.16972 11.0156 4.6875V13.0312H9.28125V4.6875C9.28125 4.16972 8.86153 3.75 8.34375 3.75C7.82597 3.75 7.40625 4.16972 7.40625 4.6875V13.0312H5.67188V4.6875C5.67188 4.16972 5.25216 3.75 4.73438 3.75C4.21659 3.75 3.79688 4.16972 3.79688 4.6875V13.0312H0.9375C0.419719 13.0312 0 13.451 0 13.9688C0 14.4865 0.419719 14.9062 0.9375 14.9062H23.0625C23.5803 14.9062 24 14.4865 24 13.9688C24 13.451 23.5803 13.0312 23.0625 13.0312Z" fill="white"></path>
											<path d="M19.4062 19.8281C19.924 19.8281 20.3438 19.4084 20.3438 18.8906V17.25C20.3438 16.7322 19.924 16.3125 19.4062 16.3125C18.8885 16.3125 18.4688 16.7322 18.4688 17.25V18.8906C18.4688 19.4084 18.8885 19.8281 19.4062 19.8281Z" fill="white"></path>
											<path d="M23.0625 18.375C22.5447 18.375 22.125 18.7947 22.125 19.3125V22.125H19.3125C18.7947 22.125 18.375 22.5447 18.375 23.0625C18.375 23.5803 18.7947 24 19.3125 24H23.0625C23.5803 24 24 23.5803 24 23.0625V19.3125C24 18.7947 23.5803 18.375 23.0625 18.375Z" fill="white"></path>
										</svg>

									</span>
                            <span class="val">
										بارکد گارانتی
									</span>
                        </a>

                        <span class="search-but">
									<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<circle cx="11.7666" cy="11.7666" r="8.98856" stroke="#333244" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></circle>
										<path d="M18.0183 18.4851L21.5423 22" stroke="#333244" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path>
									</svg>
								</span>

                    </div>
                </div>
                <!-- End Buttons -->

            </div>
        </div>
    </div>
</div>
<?php /**PATH G:\laravelProject\raizan\resources\views/home/section/header_home.blade.php ENDPATH**/ ?>