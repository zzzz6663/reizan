<?php $__env->startComponent('admin.section.content',['title'=>'لیست محصولات ']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست  محصولات </li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست    محصولات </h3>
                            <div class="card-tools">
                                <div class="btn-group-sm">
                              <a class="btn btn-info" href="<?php echo e(route('products.create' )); ?>">  محصولات  جدید</a>
                                </div>
                            </div>
                            <div class="card-tools">

                            </div>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>نام </th>
                                    <th>دسته بندی </th>
                                    <th>جریان </th>
                                    <th>رنگ </th>
                                    <th>ورژن </th>
                                    <th>قیمت</th>

                                    <th>اقدام </th>
                                </tr>
                                <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($product->name); ?> (<?php echo e($product->id); ?>)</td>
                                        <td><?php echo e(isset($product->cat)?$product->cat->name:''); ?></td>
                                        <td><?php echo e($product->current); ?></td>
                                        <td>  <?php echo e(implode(', ',$product->colores->pluck('name')->toArray())); ?></td>
                                        <td>  <?php echo e(implode(', ',$product->versions->pluck('name')->toArray())); ?></td>
                                        <td><?php echo e(number_format($product->price())); ?></td>
                                        <td>

                                            <a class="btn btn-info" href="<?php echo e(route('products.gallery.index',[ $product->id])); ?>">  گالری محصولات</a>
                                            <a class="btn btn-outline-primary" href="<?php echo e(route('products.edit',$product->id)); ?>">ویرایش</a>
                                            <form action="<?php echo e(route('products.destroy',$product->id)); ?>" style="display: inline-block" method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" value="حذف" class="btn btn-danger">
                                            </form>
                                            <a class="btn btn-outline-warning" href="<?php echo e(route('copy.product',$product->id)); ?>">کپی</a>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/product/all.blade.php ENDPATH**/ ?>