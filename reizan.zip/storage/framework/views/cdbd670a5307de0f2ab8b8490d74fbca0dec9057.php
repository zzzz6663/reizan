<?php $__env->startComponent('admin.section.content',['title'=>'  مشاهده بارکد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">مشاهده  جزئیات  بارکد</li>
    <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h5 class="card-title">  جزئیات   بارکد
                            <?php echo e($barcode->code); ?>

                            </h5>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                               محصول:
                                       </span>
                                        <?php echo e($barcode->product->name); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                               مشتری:
                                       </span>
                                        <?php echo e($barcode->customer->name); ?>

                                        <?php echo e($barcode->customer->family); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                            تخفیف
                                       </span>
                                        <?php echo e($barcode->discount); ?>%
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                            وضعیت
                                       </span>
                                       <span class="text-<?php echo e($barcode->cleared==1?'success   ':'danger   '); ?> ">
                                            <?php echo e($barcode->cleared==1?'تسویه شده':'تسویه نشده'); ?>

                                       </span>
                                    </h5>
                                </div>

                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                            تاریخ تولید:
                                       </span>
                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)->format('h-m-Y')); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                                   تاریخ خروج:

                                       </span>
                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)->format('h-m-Y')); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                           ورژن:
                                       </span>

                                        <?php echo e($barcode->version->name); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                          رنگ:
                                       </span>

                                        <?php echo e($barcode->color->name); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                          گارانتی:
                                       </span>

                                        <?php echo e($barcode->guaranty); ?>

                                        ماه
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                              مشتری:
                                       </span>

                                        <?php echo e($barcode->customer->name); ?>

                                        <?php echo e($barcode->customer->family); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                              استان:
                                       </span>

                                        <?php echo e($barcode->customer->ostan->name); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                              اپراتور:
                                       </span>
                                        <?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($operator->name); ?>

                                            <?php echo e($operator->family); ?> -
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                               توضیحات:
                                       </span>

                                        <?php echo e($barcode->info); ?>

                                    </h5>
                                </div>



                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <h5>
                                            <span class="text-primary">
                                             قطعات
                                       </span>
                                        <?php echo e(implode('-',$barcode->product->parts->pluck('name')->toArray()  )); ?>

                                    </h5>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <h5>
                                       <span class="text-primary">
                                             مونتاژ
                                       </span>
                                        <?php echo e(implode('-',$barcode->operators->pluck('name')->toArray()  )); ?>

                                    </h5>
                                </div>
                            </div>
                             <div class="row">
                                 <div class="col-12">
                                     <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">برگشت</a>
                                 </div>
                             </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/barcode/show.blade.php ENDPATH**/ ?>