<?php $__env->startComponent('admin.section.content',['title'=>'لیست بار کد ها ']); ?>
    <?php $__env->slot('bread'); ?>

        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">(حسابداری)  لیست  بار کد ها  </li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header no-border">
                            <div class="d-flex justify-content-between">
                                <h3 class="card-title">  جستو جو</h3>
                            </div>
                        </div>
                        <div class="card-tools"  >
                            <form action="<?php echo e(route('admin.accountant.all')); ?>" method="get">
                                <div class="input-group input-group-sm" style="width: 250px;">
                                    <?php echo method_field('get'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="text"  name="search" value="<?php echo e(request('search')); ?>" class="form-control float-right" placeholder=" جستجو بارکد">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- /.col-md-6 -->

            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">(حسابداری)  لیست    بار کد ها

                            </h3>
                            <br>
                            <form action="<?php echo e(route('admin.accountant.all')); ?>" method="get" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                            <div class="row">
                                <div class="col-lg-3">
                                    <label for="from">
                                        از تاریخ
                                    </label>
                                    <input type="text" hidden name="filter"  value="1" class="persian3" placeholder="از تاریخ">
                                    <input type="text" name="from" id="from" value="<?php echo e(request('from')); ?>" class="persian3" placeholder="از تاریخ">
                                </div>
                                <div class="col-lg-3">
                                    <label for="to">
                                        تا تاریخ
                                    </label>
                                    <input type="text" name="to" id="to" value="<?php echo e(request('to')); ?>" class="persian3" placeholder="تا تاریخ">
                                </div>
                                <div class="col-lg-3">
                                    <label for="customer_id">
                                           مشتری
                                    </label>
                                    <select name="customer_id" id="customer_id">
                                        <option value="">یکی را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\User::whereLevel('customer')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(request('customer_id')==$customer->id?'selected':''); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name. ' ' . $customer->family); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            </div>
                            <br>
                            <div class="row">
                                <div class="col-lg-12">

                                    <label for="all">
                                        همه
                                    </label>
                                    <input <?php echo e(request('status')=='all'?'checked':''); ?> type="radio" name="status" id="all" class="  ml-4" value="all">
                                    <label for="cleared">
                                        تسویه شده
                                    </label>
                                    <input <?php echo e(request('status')=='cleared'?'checked':''); ?> type="radio" name="status" id="all" class="   ml-4" value="cleared">
                                    <label for="uncleared">
                                        تسویه نشده
                                    </label>
                                    <input <?php echo e(request('status')=='uncleared'?'checked':''); ?> type="radio" name="status" id="all" class="   ml-4" value="uncleared">

                                </div>
                            </div>

                            <br>
                            <div class="row">
                                <div class="col-lg-3">
                                    <label for="df">
                                       درصد تخفیف از
                                    </label>
                                    <input type="number" name="df" id="df" class=" clr" value="<?php echo e(request('df')); ?>"   min="0" max="100" placeholder="از  ">
                                </div>
                                <div class="col-lg-3">
                                    <label for="dt">
                                        درصد تخفیف
                                        تا
                                    </label>
                                    <input type="number" name="dt" id="dt" class="clr " value="<?php echo e(request('dt')); ?>"    min="0" max="100" placeholder="تا   ">
                                </div>
                                <div class="col-lg-3">
                                    <label for="submit"></label>
                                    <input type="submit" id="submit" value="جست و جو">
                                </div>

                            </div>
                            </form>
                        </div>

                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>کد </th>
                                    <th>محصول </th>
                                    <th>تاریخ تولید </th>
                                    <th>تاریخ خروج </th>
                                    <th>  رنگ </th>
                                    <th>  ورژن </th>
                                    <th>  مشتری </th>
                                    <th>  اپراتور </th>
                                    <th>  توضیحات </th>
                                    <th>  وضعیت  </th>
                                    <th>  تخفیف  </th>
                                    <th>  اقدامات </th>
                                </tr>
                                <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($barcode->code); ?></td>

                                        <td><?php echo e(isset($barcode->product->name)?$barcode->product->name:''); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)); ?></td>
                                        <td>  <?php echo e(implode(', ',$barcode->colores->pluck('name')->toArray())); ?></td>
                                        <td><?php echo e(isset($barcode->version->name)?$barcode->version->name:''); ?></td>
                                        <td><?php echo e(isset($barcode->customer->name)?$barcode->customer->name .' '.$barcode->customer->family :''); ?></td>
                                        <td><?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($operator->name); ?>

                                                <?php echo e($operator->family); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($barcode->info); ?></td>

                                        <td>
                                            <span class="text-<?php echo e($barcode->cleared==1?'success':'danger'); ?>">
                                                <?php echo e($barcode->cleared==1?'تسویه شده':'تسویه نشده'); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($barcode->discount); ?></td>

                                        <td>
                                            <a class="btn btn-outline-primary"  href="<?php echo e(route('admin.accountant.edit',$barcode->id)); ?>">ویرایش</a>





                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">

                            <div class="pagi">
                                <?php echo e($barcodes->appends(Request::all())->links('admin.pagination')); ?>

                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/accountant/all.blade.php ENDPATH**/ ?>