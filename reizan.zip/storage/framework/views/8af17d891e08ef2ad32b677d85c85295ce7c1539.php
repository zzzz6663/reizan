<?php $__env->startComponent('admin.section.content',['title'=>'  ایجاد  انتقال']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد    انتقال</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم    انتقال
                            <?php echo e($barcode->code); ?>

                            </h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- form start -->
                        <form role="form" action="<?php echo e(route('transfer.store')); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="color">مقصد  </label>
                                    <input type="text" name="barcode_id" value="<?php echo e($barcode->id); ?>" hidden>
                                    <select class="form-control" name="to_id" id="customer">
                                        <option   value="">یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\User::whereIn('level',['operator','qc','accountant','service','producer'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($goal->id); ?>">
                                        <?php echo e($goal->name); ?>

                                        <?php echo e($goal->family); ?>

                                       ( <?php echo e(__('arr.'.$goal->level)); ?>)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">توضیحات    </label>
                                    <textarea name="info_from" id="" class="form-control" cols="30" rows="10"><?php echo e(old('info_from')); ?></textarea>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('cats.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/transfer/create.blade.php ENDPATH**/ ?>