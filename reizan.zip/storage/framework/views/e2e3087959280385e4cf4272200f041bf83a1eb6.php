<?php $__env->startComponent('admin.section.content',['title'=>'  ایجاد    مشتری']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد  مشتری</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم  مشتری</h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- form start -->
                        <form role="form" action="<?php echo e(route('customer.store')); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name">نام    </label>
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" id="name" placeholder="نام را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="family">     نام خانوادگی</label>
                                    <input type="text" name="family" value="<?php echo e(old('family')); ?>" class="form-control" id="family" placeholder=" نام خانوادگی را وارد کنید">
                                </div>

                                <div class="form-group">
                                    <label for="mobile">       همراه </label>
                                    <input type="number" name="mobile" value="<?php echo e(old('mobile')); ?>" class="form-control" id="mobile" placeholder=" همراه   را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="tel">       ثابت </label>
                                    <input type="number" name="tel" value="<?php echo e(old('tel')); ?>" class="form-control" id="tel" placeholder="   تلفن ثابت را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="ostan">       استان</label>
                                    <select class="form-control" name="ostan_id" id="ostan">
                                        <option  >استان را انتخاب کنید </option>
                                        <?php $__currentLoopData = \App\Models\Ostan::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ostan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('ostan_id')==$ostan->id?'selecteddddd':''); ?> value="<?php echo e($ostan->id); ?>"><?php echo e($ostan->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="shahr">       شهر</label>
                                    <select class="form-control" name="shahr_id" id="shahr">

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="address">       ادرس</label>
                                    <input type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control" id="address" placeholder="   ادرس      ">
                                </div>
                                <div class="form-group">
                                    <label for="telegram">       تلگرام</label>
                                    <input type="text" name="telegram" value="<?php echo e(old('telegram')); ?>" class="form-control" id="telegram" placeholder="   تلگرام      ">
                                </div>
                                <div class="form-group">
                                    <label for="instagram">       اینستاگرام</label>
                                    <input type="text" name="instagram" value="<?php echo e(old('instagram')); ?>" class="form-control" id="instagram" placeholder="   تلگرام      ">
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('admin.customer')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/customer/create.blade.php ENDPATH**/ ?>