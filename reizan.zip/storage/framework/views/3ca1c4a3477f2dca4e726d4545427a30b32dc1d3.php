<option  >استان را انتخاب کنید </option>
<?php $__currentLoopData = $ostan->shahrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shahr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($shahr->id); ?>"><?php echo e($shahr->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\laravelProject\raizan\resources\views/admin/get_shahr.blade.php ENDPATH**/ ?>