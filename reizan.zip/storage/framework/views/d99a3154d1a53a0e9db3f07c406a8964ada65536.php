<?php $__env->startComponent('admin.section.content',['title'=>'      اضافه کردن عکس خرابی ها']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">   اضافه کردن عکس خرابی ها
        </li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">

                            </h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card-body">
                            <div class="row">
                                    <form action="<?php echo e(route('repair.add.images',$repair->id)); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>
                                        <label for="images">عکس های دستگاه </label>
                                        <input type="file" id="images" accept="image/*" multiple="true" name="images[]"   >
                                        <input class="btn btn-primary" type="submit" value="ثبت"  class="btn btn-primary"  >
                                    </form>
                                    <a class="btn btn-danger" href="<?php echo e(route('repair.index',['code'=>$repair->barcode->id])); ?>">
                                        برگشت
                                    </a>
                            </div>
                        </div>


                    </div>

                </div>
                <div id="qr-reader" style="width: 600px"></div>
                

                






            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/repair/images.blade.php ENDPATH**/ ?>