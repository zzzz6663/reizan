<!-- Navbar -->
<nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('login')); ?>" class="nav-link">خانه</a>
        </li>



    </ul>

    <!-- SEARCH FORM -->











    <!-- Right navbar links -->



























































































</nav>
<!-- /.navbar -->
<?php /**PATH G:\laravelProject\reizan\resources\views/admin/section/navbar.blade.php ENDPATH**/ ?>