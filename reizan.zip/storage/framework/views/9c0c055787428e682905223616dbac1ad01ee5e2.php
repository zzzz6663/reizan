<?php $__env->startComponent('admin.section.content',['title'=>'  ایجاد  بارکد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد  بارکد</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم  بارکد</h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- form start -->
                        <form role="form"  action="<?php echo e(route('barcode.store')); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="exampleInputEmail1"> بارکد</label>
                                    <input type="number" name="code" value="<?php echo e(old('code' ,\App\Models\Barcode::latest()->first()? \App\Models\Barcode::latest()->first()->code+1:1)); ?>" class="form-control" id="exampleInputEmail1" placeholder="نام را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="product">محصول  </label>
                                    <select class="form-control" name="product_id" id="product">
                                        <option value="" disabled >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(old('product_id')==$product->id?'selected':''); ?> value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="produce">  تاریخ تولید</label>
                                    <input type="text" name="produce" value="<?php echo e(old('produce')); ?>" class="form-control persian" id="produce" placeholder="تاریخ تولید را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="deliver">  تاریخ خروج</label>
                                    <input type="text" name="deliver" value="<?php echo e(old('deliver')); ?>" class="form-control persian3" id="deliver" placeholder="تاریخ خروج را وارد کنید">
                                </div>
                                <div   >
                                    <div class="form-group ">
                                        <input type="checkbox" <?php echo e((old('deliver') || old('customer_id'))?'checked':''); ?> value="1" style="  display:inline-block;   width: inherit; margin-left: 12px;"  class="form-control " id="deliverd" placeholder="تاریخ خروج را وارد کنید">
                                        <label for="deliverd">    نمایش تاریخ  خروج</label>
                                    </div>
                                </div>
                                <div class="dateh <?php echo e(old('deliver')?'':'disnon'); ?>"  >
                                    <div class="form-group ">
                                        <label for="deliver">  تاریخ خروج</label>
                                        <input type="text" name="deliver" value="<?php echo e(old('deliver')); ?>" class="form-control persian3" id="deliver" placeholder="تاریخ خروج را وارد کنید">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="version">  ورژن  </label>
                                    <select class="form-control select2" multiple name="versions[]" id="version">
                                        <option value="" disabled>یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\Version::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <option  <?php echo e(in_array($version->id,old('versions',[]))?'selected':''); ?> value="<?php echo e($version->id); ?>"><?php echo e($version->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="color">رنگ  </label>
                                    <select class="form-control select2" multiple name="colores[]" id="color">
                                        <option value="" disabled>یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\Color::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(in_array($color->id,old('colores',[]))?'selected':''); ?> value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="dateh  <?php echo e(old('customer_id')?'':'disnon'); ?>" >
                                    <div class="form-group">
                                        <label for="color">مشتری  </label>
                                        <select class="form-control" name="customer_id" id="customer">
                                            <option  value=""  >یک مورد را انتخاب کنید</option>
                                            <?php $__currentLoopData = \App\Models\User::whereLevel('customer')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  <?php echo e(old('customer_id')==$customer->id?'selected':''); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> <?php echo e($customer->family); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                  </div>

                                <div class="form-group">
                                    <label for="color">مونتاژ کار  </label>
                                    <select class="form-control select2" name="operators[]" id="operator" multiple>
                                        <?php $__currentLoopData = \App\Models\User::whereLevel('operator')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(in_array($operator->id,old('operators',[]))?'selected':''); ?> value="<?php echo e($operator->id); ?>"><?php echo e($operator->name); ?> <?php echo e($operator->family); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="info">توضیحات بارکد</label>
                                    <textarea name="info" id="info" class="form-control" cols="30" rows="10"><?php echo e(old('info')); ?></textarea>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer " >
                                <button type="submit" id="ssubmit" class="btn disnon btn-primary">ارسال</button>
                                <span class="btn btn-primary trigger" data-id='1' id="show_msg" >ذخیره</span>
                                <div id="modal_1" class="modal" style="">
                                    <h1>موارد زیر را تایید میکنید؟</h1>
                                    <p>
                                        <span style="color:rgb(0, 0, 0);font-size:25px" class="title">    نام مشتری   :</span>
                                        <span  style="color:green;font-size:25px"  class="content" id="cname"></span>
                                    </p>
                                    <p>
                                        <span  style="color:rgb(0, 0, 0);font-size:25px"  class="title" >   تاریخ خروج :</span>
                                        <span  style="color:rgb(210, 57, 11);font-size:25px"  class="content" id="dtate"></span>
                                    </p>
                                    <span class="btn btn-dark " id="myes" >بله</span>
                                    <span class="btn btn-danger " id="mno" >خیر</span>


                                </div>

                                <a class="btn btn-success " href="<?php echo e(route('barcode.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/barcode/create.blade.php ENDPATH**/ ?>