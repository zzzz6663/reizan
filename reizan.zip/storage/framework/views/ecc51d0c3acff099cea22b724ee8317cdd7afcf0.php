<?php $__env->startComponent('admin.section.content',['title'=>'  به روز رسانی    بارکد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد  بارکد</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم  بارکد</h3>
                        </div>
                        <!-- /.card-header -->
                    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- form start -->
                        <form role="form" action="<?php echo e(route('barcode.update',$barcode->id)); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">نام بارکد</label>
                                    <input type="text" name="code" value="<?php echo e(old('code',$barcode->code)); ?>" class="form-control" id="exampleInputEmail1" placeholder="نام را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="product">محصول  </label>
                                    <select class="form-control" name="product_id" id="product">
                                        <option >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(old('product_id',$barcode->product_id)==$product->id?'selected':''); ?> value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="produce">  تاریخ تولید</label>
                                    <input type="text" name="produce" value="<?php echo e(old('produce',$barcode->produce)); ?>" class="form-control persian" id="produce" placeholder="تاریخ تولید را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="deliver">  تاریخ خروج</label>
                                    <input type="text" name="deliver" value="<?php echo e(old('deliver',$barcode->deliver)); ?>" class="form-control persian" id="deliver" placeholder="تاریخ خروج را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="version">  ورژن  </label>
                                    <select class="form-control" name="version_id" id="version">
                                        <option >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\Version::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('version_id',$barcode->version_id)==$version->id?'selected':''); ?> value="<?php echo e($version->id); ?>"><?php echo e($version->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="color">رنگ  </label>
                                    <select class="form-control" name="color_id" id="color">
                                        <option >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\Color::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(old('color_id',$barcode->color_id)==$color->id?'selected':''); ?> value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="color">مشتری  </label>
                                    <select class="form-control" name="customer_id" id="customer">
                                        <option >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\User::whereLevel('customer')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(old('customer_id',$barcode->customer_id)==$customer->id?'selected':''); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> <?php echo e($customer->family); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="color">اپراتور  </label>
                                    <select class="form-control select2" name="operators[]" id="operator" multiple>
                                        <option >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\User::whereLevel('operator')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(in_array($operator->id,old('operators',$barcode->operators()->pluck('id')->toArray()))?'selected':''); ?> value="<?php echo e($operator->id); ?>"><?php echo e($operator->name); ?> <?php echo e($operator->family); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">توضیحات بارکد</label>
                                    <textarea name="info" id="" class="form-control" cols="30" rows="10"><?php echo e(old('info',$barcode->info)); ?></textarea>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('barcode.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/barcode/edit.blade.php ENDPATH**/ ?>