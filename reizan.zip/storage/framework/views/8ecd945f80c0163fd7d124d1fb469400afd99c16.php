<!DOCTYPE html>
<html lang="en">
<head>


    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/home/css/style.css">
    <link rel="stylesheet" href="/home/css/responsive.css">
    <link rel="stylesheet" href="/css/iziToast.css">
    <link rel="stylesheet" href="/css/app.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(@csrf_token()); ?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

</head>
<body>
<?php echo $__env->make('home.section.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="site-holder">

    <?php echo $__env->yieldContent('main_body'); ?>
    <?php echo $__env->make('home.section.footer_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<script type="text/javascript" src="/home/js/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="/home/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="/home/js/metisMenu.js"></script>
<script type="text/javascript" src="/home/js/lightbox.js"></script>
<script type="text/javascript" src="/home/js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="/home/js/imagesloaded.pkgd.js"></script>
<script type="text/javascript" src="/home/js/template.js"></script>
<script src="/js/iziToast.js"></script>
<script src="/js/fun.js"></script>

<script type="text/javascript" src="/js/app.js"></script>


<?php echo \Anhskohbo\NoCaptcha\Facades\NoCaptcha::renderJs(); ?>

</body>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH G:\laravelProject\reizan\resources\views/master/home.blade.php ENDPATH**/ ?>