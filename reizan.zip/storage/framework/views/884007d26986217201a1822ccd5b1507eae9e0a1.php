<?php $__env->startComponent('admin.section.content',['title'=>'  تایید  انتقال']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">تایید    انتقال</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم    تایید انتقال
                            <?php echo e($transfer->barcode->code); ?>

                            ارسال از
                            <?php echo e($transfer->from->name); ?>

                            <?php echo e($transfer->from->family); ?>

                            </h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- form start -->
                        <form role="form" action="<?php echo e(route('transfer.update',$transfer->id)); ?>" method="post" enctype="multipart">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>

                            <div class="card-body">
                                <p>
                                    <?php echo e($transfer->info_from); ?>

                                </p>
                                <div class="form-group">
                                    <label for="color">وضعیت  </label>
                                    <select class="form-control" name="status" id="customer">
                                        <option   value="">یک مورد را انتخاب کنید</option>
                                        <option value="1">تایید</option>
                                        <option value="0">رد </option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">توضیحات    </label>
                                    <textarea name="info_to" id="" class="form-control" cols="30" rows="10"><?php echo e(old('info_to')); ?></textarea>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('cats.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/transfer/edit.blade.php ENDPATH**/ ?>