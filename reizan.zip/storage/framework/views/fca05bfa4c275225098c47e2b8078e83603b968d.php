<?php $__env->startComponent('admin.section.content',['title'=>'لیست بارکد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست  بارکد</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                            <div class="card-body">
                                <h1>
                                    وضعیت
                                </h1>
                                <div class="row">
                                    <div class="col-sm-2 col-md-2">
                                        <h4 class="text-center">        ثبت اولیه </h4>

                                        <div class="color-palette-set text-center">
                                            <a href="<?php echo e(route('repair.list',['status'=>'submit'])); ?>" class="bg-danger disabled color-palette p-1"><span><?php echo e(\App\Models\Repair::whereStatus('submit')->count()); ?> عدد</span></a>
                                            
                                        </div>
                                    </div>
                                    <div class="col-sm-2 col-md-2">
                                        <h4 class="text-center">        ثبت نهایی </h4>

                                        <div class="color-palette-set text-center">
                                            <a href="<?php echo e(route('repair.list',['status'=>'saves'])); ?>" class="bg-primary disabled color-palette p-1"><span><?php echo e(\App\Models\Repair::whereStatus('saves')->count()); ?> عدد</span></a>
                                            
                                        </div>
                                    </div>
                                    <div class="col-sm-2 col-md-2">
                                        <h4 class="text-center">        تحویل   </h4>

                                        <div class="color-palette-set text-center">
                                            <a href="<?php echo e(route('repair.list',['status'=>'delivered'])); ?>" class="bg-warning disabled color-palette p-1"><span><?php echo e(\App\Models\Repair::whereStatus('delivered')->count()); ?> عدد</span></a>
                                            
                                        </div>
                                    </div>

                                </div>
                                <br>
                                <br>
                                <h1>
                                    برگشتی
                                </h1>

                                <div class="row">

                                    <div class="col-sm-4 col-md-2">
                                        <h4 class="text-center">    مجموع برگشتی </h4>
                                        <div class="color-palette-set">
                                            <div class="bg-primary disabled color-palette p-1">
                                                    <a href="<?php echo e(route('barcode.index',['status'=>'all_back'])); ?>">
                                                        <span><?php echo e(\App\Models\Barcode::has('repairs','>',0)->count()); ?> عدد</span>
                                                    </a>
                                            </div>
                                            
                                        </div>
                                    </div>


                                    <div class="col-sm-4 col-md-2">
                                        <h4 class="text-center">  روز گذشته  </h4>
                                        <div class="color-palette-set">
                                            <div class="bg-success disabled color-palette p-1">
                                                <a href="<?php echo e(route('barcode.index',['status'=>'day_past_back'])); ?>">
                                                    <span><?php echo e(\App\Models\Barcode::
                                                    whereHas('repairs',function($query) {
                                                        $query->where('created_at','=',\Carbon\Carbon::now()->subDay());
                                                    })
                                                    ->count()); ?> عدد</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-4 col-md-2">
                                        <h4 class="text-center">  هفته گذشته  </h4>
                                        <div class="color-palette-set">
                                            <div class="bg-danger disabled color-palette p-1">
                                                <a href="<?php echo e(route('barcode.index',['status'=>'week_past_back'])); ?>">
                                                    
                                                    <span><?php echo e(\App\Models\Barcode::
                                                        whereHas('repairs',function($query) {
                                                            $query->whereBetween('created_at', [\Carbon\Carbon::now()->startOfWeek(), \Carbon\Carbon::now()->endOfWeek()]);
                                                        })
                                                        ->count()); ?> عدد</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-4 col-md-2">
                                        <h4 class="text-center">  ماه گذشته  </h4>
                                        <div class="color-palette-set">
                                            <div class="bg-gray disabled color-palette p-1">
                                                <a href="<?php echo e(route('barcode.index',['status'=>'month_past_back'])); ?>">
                                                    <span><?php echo e(\App\Models\Barcode::
                                                        whereHas('repairs',function($query) {
                                                            $query->whereBetween('created_at', [\Carbon\Carbon::now()->startOfMonth(), \Carbon\Carbon::now()->endOfMonth()]);
                                                        })
                                                        ->count()); ?> عدد</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>



                                </div>
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            <!-- /.row -->
                            </div>
                        <div class="card-body">
                            <h1>
                                خرابی ها
                            </h1>
                            <div class="row">
                                <div class="col-sm-2 col-md-2">
                                    <h4 class="text-center">           یک بار خرابی   </h4>
                                    <div class="color-palette-set text-center">
                                        <a href="<?php echo e(route('barcode.index',['status'=>'repair_count','count'=>1])); ?>" class="bg-warning disabled color-palette p-1"><span><?php echo e(\App\Models\Barcode::has('repairs','=','1')->count()); ?> عدد</span></a>
                                        
                                    </div>
                                </div>
                                <div class="col-sm-2 col-md-2">
                                    <h4 class="text-center">           دوبار خرابی   </h4>
                                    <div class="color-palette-set text-center">
                                        <a href="<?php echo e(route('barcode.index',['status'=>'repair_count','count'=>2])); ?>" class="bg-warning disabled color-palette p-1"><span><?php echo e(\App\Models\Barcode::has('repairs','=','2')->count()); ?> عدد</span></a>
                                        
                                    </div>
                                </div>
                                <div class="col-sm-2 col-md-2">
                                    <h4 class="text-center">             سه بار خرابی   </h4>
                                    <div class="color-palette-set text-center">
                                        <a href="<?php echo e(route('barcode.index',['status'=>'repair_count','count'=>3])); ?>" class="bg-warning disabled color-palette p-1"><span><?php echo e(\App\Models\Barcode::has('repairs','=','3')->count()); ?> عدد</span></a>
                                        
                                    </div>
                                </div>
                                <div class="col-sm-2 col-md-2">
                                    <h4 class="text-center">                  چهار بار خرابی   </h4>
                                    <div class="color-palette-set text-center">
                                        <a href="<?php echo e(route('barcode.index',['status'=>'repair_count','count'=>4])); ?>" class="bg-warning disabled color-palette p-1"><span><?php echo e(\App\Models\Barcode::has('repairs','=','4')->count()); ?> عدد</span></a>
                                        
                                    </div>
                                </div>
                            </div>
                            </div>
                        <div class="card-body">
                            <h1>
                                انبار
                            </h1>
                            <div class="row">
                                <div class="col-sm-4 col-md-2">
                                    <h4 class="text-center">موجودی   انبار</h4>

                                    <div class="color-palette-set">
                                        <div class="bg-primary disabled color-palette p-1">
                                            <a href="<?php echo e(route('barcode.index',['status'=>'store'])); ?>">
                                                <span><?php echo e(\App\Models\Barcode::where('customer_id',null)->count()); ?> عدد</span>
                                            </a>

                                        </div>
                                        
                                    </div>
                                </div>

                                <div class="col-sm-4 col-md-2">
                                    <h4 class="text-center">  مجموع تولید    </h4>
                                    <div class="color-palette-set">
                                        <div class="bg-success disabled color-palette p-1">
                                            <a href="<?php echo e(route('barcode.index',['status'=>'produce'])); ?>">
                                                <span><?php echo e(\App\Models\Barcode::where('created_at','<',\Carbon\Carbon::now())->count()); ?> عدد</span>
                                            </a>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-4 col-md-2">
                                    <h4 class="text-center">  هفته گذشته  </h4>
                                    <div class="color-palette-set">
                                        <div class="bg-danger disabled color-palette p-1">
                                            <a href="<?php echo e(route('barcode.index',['status'=>'week_produce'])); ?>">
                                                <span><?php echo e(\App\Models\Barcode::whereBetween('created_at', [\Carbon\Carbon::now()->startOfWeek(), \Carbon\Carbon::now()->endOfWeek()])->count()); ?> عدد</span>
                                            </a>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-4 col-md-2">
                                    <h4 class="text-center">  ماه گذشته  </h4>
                                    <div class="color-palette-set">
                                        <div class="bg-gray disabled color-palette p-1">
                                            <a href="<?php echo e(route('barcode.index',['status'=>'month_produce'])); ?>">
                                                <span><?php echo e(\App\Models\Barcode::whereBetween('created_at', [\Carbon\Carbon::now()->startOfMonth(), \Carbon\Carbon::now()->endOfMonth()])->count()); ?> عدد</span>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-2">
                                    <h4 class="text-center">    فروش رفته  </h4>
                                    <div class="color-palette-set">
                                        <div class="bg-warning disabled color-palette p-1">
                                            <a href="<?php echo e(route('barcode.index',['status'=>'sold'])); ?>">
                                                <span><?php echo e(\App\Models\Barcode::where('customer_id','!=',null)->count()); ?> عدد</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>













                            <!-- /.row -->
                        </div>

                        <?php endif; ?>

                        <div class="card-header">
                            <h3 class="card-title">  لیست    بارکد

                               <span style="color:green;font-size:28px">
                                <?php echo e($barcodes->total()); ?>

                                عدد
                               </span>
                            </h3>
                            <div class="card-tools">
                                <div class="btn-group-sm">
                                    <a class="btn btn-warning" href="<?php echo e(route('barcode.index',['all'=>1])); ?>">  نمایش موجودی  </a>
                                </div>
                            </div>
                            <div class="card-tools"  style="left:  27rem">
                                <div class="btn-group-sm">
                                    <a class="btn btn-danger" href="<?php echo e(route('barcode.index',['store'=>1])); ?>">    داخل انبار  </a>
                                </div>
                            </div>
                            <div class="card-tools"  style="left:  38rem">
                                <div class="btn-group-sm">
                                    <a class="btn btn-primary" href="<?php echo e(route('barcode.index',['store'=>0])); ?>">    خارج انبار  </a>
                                </div>
                            </div>
                            <div class="card-tools"  style="left:  9rem">
                                <div class="btn-group-sm">
                                    <a class="btn btn-info" href="<?php echo e(route('barcode.create')); ?>">  بارکد جدید</a>
                                </div>
                            </div>
                            <div class="card-tools" style="left: 16rem">


                                <form action="<?php echo e(route('barcode.index')); ?>" method="GET">
                                
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <?php echo method_field('get'); ?>
                                        <?php echo csrf_field(); ?>
                                        <?php if(request('status')): ?>
                                        <input type="text" hidden  name="status" value="<?php echo e(request('status')); ?>" class="form-control float-right" >
                                        <?php endif; ?>
                                        <input type="text"  name="search" value="<?php echo e(request('search')); ?>" class="form-control float-right" placeholder="جستجو">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('code'));?> </th>
                                    <th>محصول </th>
                                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('produce'));?></th>
                                    <th>    <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('deliver'));?> </th>
                                    <th>  رنگ </th>
                                    <th>  ورژن </th>
                                    <th>  مشتری </th>
                                    <th>  اپراتور </th>
                                    <th>  آخرین مقصد </th>
                                    <th>  توضیحات </th>
                                    <th>  اقدامات </th>
                                </tr>
                                <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($barcode->code); ?></td>

                                        <td><?php echo e(isset($barcode->product)?$barcode->product->name:''); ?></td>
                                        <td>
                                            <?php if($barcode->produce): ?>
                                            <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)); ?>

                                            <?php endif; ?>
                                         </td>
                                        <td>
                                            <?php if($barcode->deliver): ?>
                                            <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)); ?>


                                            <?php endif; ?>
                                        </td>
                                        <td>  <?php echo e(implode(', ',$barcode->colores->pluck('name')->toArray())); ?></td>
                                        <td>  <?php echo e(implode(', ',$barcode->versions->pluck('name')->toArray())); ?></td>
                                        
                                        <td><?php echo e(isset($barcode->customer)?$barcode->customer->name.' ' .$barcode->customer->family:'----'); ?></td>
                                        <td><?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($operator->name); ?>

                                                <?php echo e($operator->family); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <?php if($barcode->lastuser): ?>
                                            <?php echo e($barcode->lastuser->name); ?>

                                            <?php echo e($barcode->lastuser->family); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($barcode->info); ?></td>

                                        <td>
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                            <a class="btn btn-outline-secondary" href="<?php echo e(route('barcode.show',$barcode->id)); ?>">مشاهده</a>
                                            <?php endif; ?>
                                            <a class="btn btn-outline-primary" href="<?php echo e(route('barcode.edit',$barcode->id)); ?>">ویرایش</a>
                                            <form action="<?php echo e(route('barcode.destroy',$barcode->id)); ?>" style="display: inline-block" method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="submit"  onclick="return confirm('Are you sure?')" value="حذف" class="btn btn-danger">
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">

                            <div class="pagi">

                                <?php echo e($barcodes->appends(Request::all())->links('admin.pagination')); ?>

                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/barcode/all.blade.php ENDPATH**/ ?>