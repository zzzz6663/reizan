


    <div class="col-md-12">
        <div class="row">

            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            صداهای بارکد
                            <?php echo e($barcode->code); ?>

                      </h3>
                      <div class="card-tools">
                        <div class="btn-group-sm">
                            <span id="start_button" class="btn btn-danger" >
                                ضبط کردن
                            </span>
                            <span id="stop_button" class="btn btn-success disnon" data-barcode="<?php echo e($barcode->id); ?>">
                                توقف
                            </span>
                            <span id="gif" class="  " data-barcode="<?php echo e($barcode->id); ?>">
                               
                            </span>
                        </div>
                    </div>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>توسط </th>
                                    <th>بارکد </th>
                                    <th>   تاریخ </th>
                                    <th> پخش</th>
                                    <th> اقدام</th>
                                </tr>
                                <?php $__currentLoopData = $barcode->sounds()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sound): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <?php echo e($sound->user->name); ?>

                                        <?php echo e($sound->user->family); ?>

                                    </td>
                                    <td>
                                        <?php echo e($sound->barcode->code); ?>

                                    </td>
                                    <td><?php echo e(\Morilog\Jalali\Jalalian::forge($sound->created_at)); ?></td>
                                    <td>
                                        <audio id="song1" src="<?php echo e(asset('/src/voice/'. $sound->name)); ?>" controls></audio>
                                    </td>
                                    <td>
                                     <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                        <form action="<?php echo e(route('repair.remove.voice')); ?>"
                                            style="display: inline-block" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('post'); ?>
                                            <?php echo method_field('post'); ?>
                                            <input type="text" name="sound_id" hidden value="<?php echo e($sound->id); ?>">
                                                 <input
                                                type="submit" onclick="return confirm('Are you sure?')" value="حذف"
                                                class="btn btn-danger">
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>






<?php /**PATH G:\laravelProject\reizan\resources\views/admin/barcode/record.blade.php ENDPATH**/ ?>