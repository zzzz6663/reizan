<?php $__env->startComponent('admin.section.content',['title'=>'لیست خرابی ها ']); ?>
    <?php $__env->slot('bread'); ?>

        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">  لیست  خرابی ها  </li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
























            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست    خرابی ها

                            </h3>
                            <br>
                            <form action="<?php echo e(route('repair.list')); ?>" method="get" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <h1>
                                    تاریخ مراجعه
                                </h1>
                            <div class="row">


                                <div class="col-lg-3">
                                    <label for="from">
                                        از تاریخ
                                    </label>
                                    <input type="text" hidden name="filter"  value="1" class="persian3" placeholder="از تاریخ">
                                    <input type="text" name="from" id="from" value="<?php echo e(request('from')); ?>" class="persian3" placeholder="از تاریخ">
                                </div>
                                <div class="col-lg-3">
                                    <label for="to">
                                        تا تاریخ
                                    </label>
                                    <input type="text" name="to" id="to" value="<?php echo e(request('to')); ?>" class="persian3" placeholder="تا تاریخ">
                                </div>












                            </div>
                            <br>

                                <h1>
                                    تاریخ تولید
                                </h1>
                                <div class="row">


                                    <div class="col-lg-3">
                                        <label for="pfrom">
                                            از تاریخ
                                        </label>
                                        <input type="text" name="pfrom" id="pfrom" value="<?php echo e(request('pfrom')); ?>" class="persian3" placeholder="از تاریخ">
                                    </div>
                                    <div class="col-lg-3">
                                        <label for="pto">
                                            تا تاریخ
                                        </label>
                                        <input type="text" name="pto" id="pto" value="<?php echo e(request('pto')); ?>" class="persian3" placeholder="تا تاریخ">
                                    </div>
                                </div>
                                <br>

                                <h1>
                                    تاریخ فروش
                                </h1>
                                <div class="row">


                                    <div class="col-lg-3">
                                        <label for="sfrom">
                                            از تاریخ
                                        </label>
                                        <input type="text" name="sfrom" id="sfrom" value="<?php echo e(request('sfrom')); ?>" class="persian3" placeholder="از تاریخ">
                                    </div>
                                    <div class="col-lg-3">
                                        <label for="sto">
                                            تا تاریخ
                                        </label>
                                        <input type="text" name="sto" id="sto" value="<?php echo e(request('sto')); ?>" class="persian3" placeholder="تا تاریخ">
                                    </div>
                                </div>
                                <br>
                            <div class="row">
















                                <div class="col-lg-12">
                                    <label for="submit"></label>
                                    <input type="submit" id="submit" value="جست و جو">
                                    <?php if($repairs->count()>0): ?>
                                    <input type="submit" id="submit" name="excel" value="  excel  ">
                                    <?php endif; ?>
                                </div>
                            </div>


                            </form>
                        </div>

                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>کد </th>
                                    <th> همراه مصرف کننده </th>
                                    <th>مالک </th>
                                    <th>وضعیت </th>
                                    <th>محصول </th>
                                    <th>تاریخ تولید </th>
                                    <th>تاریخ خروج </th>
                                    <th>  رنگ </th>
                                    <th>  ورژن </th>
                                    <th>   تاریخ ثبت خرابی </th>
                                </tr>
                                <?php $__currentLoopData = $repairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>

                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('repair.index',['code'=>$repair->barcode->id])); ?>">
                                                <?php echo e($repair->barcode->code); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($repair->tell); ?></td>
                                        <td><?php echo e($repair->name); ?></td>
                                        <td><?php echo e(__('arr.'.$repair->status)); ?></td>
                                        <td><?php echo e(isset($repair->barcode->product->name)?$repair->barcode->product->name:''); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($repair->barcode->produce)); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($repair->barcode->deliver)); ?></td>
                                        <td>  <?php echo e(implode(', ',$repair->barcode->colores->pluck('name')->toArray())); ?></td>
                                        <td><?php echo e(isset($repair->barcode->version->name)?$repair->barcode->version->name:''); ?></td>
                                        <td>
                                            <?php echo e(\Morilog\Jalali\Jalalian::forge($repair->created_at)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">

                            <div class="pagi">
                                <?php echo e($repairs->appends(Request::all())->links('admin.pagination')); ?>

                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/report/repair_list.blade.php ENDPATH**/ ?>