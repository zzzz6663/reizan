<?php $__env->startComponent('admin.section.content',['title'=>'فرم جستو جو  ']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">فرم جستو جو   </li>
    <?php $__env->endSlot(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  فرم   موجودی     </h3>
                            <div class="card-tools">



                            </div>
                            <div class="card-tools">

                            </div>

                            <div class="card card-success">
                                <div class="card-header">
                                    <h3 class="card-title">اطلاعات جست و جو  </h3>
                                </div>
                                <form action="<?php echo e(route('admin.stock')); ?>" method="get" autocomplete="off">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('get'); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="productpart">محصول  </label>
                                                <select class="form-control" name="product" id="">
                                                    <option value="">یک مورد را انتخاب کنید</option>
                                                    <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option  <?php echo e(request('product')==$product->id?'selected':''); ?> value="
                                                            <?php echo e($product->id); ?>"><?php echo e($product->name); ?>

                                                            (<?php echo e($product->barcodes()->count()); ?> بارکد)
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-lg-4">
                                            <label for="submit" id="submit">نتیجه:
                                            <?php echo e($barcodes->total()); ?>

                                                عدد
                                            </label>
                                            <input type="submit" id="submit" value="جستو جو" class="btn form-control btn-danger">
                                        </div>
                                        <div class="col-lg-4">
                                            <label for="submit" id="submit">دوباره:
                                            </label>
                                            <a href="<?php echo e(route('admin.stock')); ?>" class="btn btn-warning form-control">ریست کردن</a>

                                        </div>
                                    </div>
                                </div>
                                </form>

                                <!-- /.card-body -->
                            </div>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>کد </th>
                                    <th>محصول </th>
                                    <th>تاریخ تولید </th>
                                    <th>تاریخ خروج </th>
                                    <th>  ورژن </th>
                                    <th>  رنگ </th>
                                    <th>  مشتری </th>
                                    <th>  اپراتور </th>
                                    <th>  توضیحات </th>
                                    <th>  اقدامات </th>
                                </tr>
                                <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <a class="text-success" href="<?php echo e(route('barcode.show',$barcode->id)); ?>"><?php echo e($barcode->code); ?></a>
                                        </td>

                                        <td><?php echo e(isset($barcode->product)?$barcode->product->name:''); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)); ?></td>
                                        <td>  <?php echo e(implode(', ',$barcode->colores->pluck('name')->toArray())); ?></td>
                                        <td><?php echo e(isset($barcode->version)?$barcode->version->name:'----'); ?></td>
                                        <td><?php echo e(isset($barcode->customer)?$barcode->customer->name.' '.$barcode->customer->family:'----'); ?></td>
                                        <td><?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($operator->name); ?>

                                                <?php echo e($operator->family); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($barcode->info); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is_admin')): ?>
                                                <a class="btn btn-outline-secondary" href="<?php echo e(route('barcode.show',$barcode->id)); ?>">مشاهده</a>
                                            <?php endif; ?>






                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">

                            <div class="pagi">
                                <?php echo e($barcodes->appends(Request::all())->links('admin.pagination')); ?>

                            </div>

                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>

    <?php $__env->slot('script'); ?>
    <script>

        let createNewDls=({obj_a,id,last})=>{

            var list;
            var i=id;

            `
            ${
                $.each(obj_a, function(index, value){
                    console.log(858585)
                    console.log(last)
                    list =  `


                       <div class="col-lg-6  col-md-12 part_op" id="dls-${last}">
                            <div class="row">
                                <div class="col-2">
                                    <h5>
                                        ${value}
                                    </h5>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="">بیشینه</label>
                                        <input type="number" name="dls[${last}][max]" class="form-control" value="" placeholder="max">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="">کمینه </label>
                                        <input type="number" name="dls[${last}][min]" class="form-control" value="" placeholder="min">
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class=" form-group">
                                        <span style="position:relative; top: 37px" data-val="${last}" class="btn btn-warning remove_r form-control" data-cl="ch${last}"  data-ids="${last}" data-id="dls[${i}][status]">حذف</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                      `
                    // i++;

                })
            }

        `
            return list;
        }

        // $("select").on("select2:unselect", function (e) {
        //     var value=   e.params.data.id;
        //     alert(value);
        // });
        $('#dls').on("select2:unselect", function(e){
            var el=$(this)
            let last=e.params.data.id
            let ids='dls-'+last
            // var elem = document.querySelector('#'+id);
            // elem.style.display = 'none';
            $('.part_op').each(function() {
                let el=$(this)
                let id=el.attr('id')
                if (ids==id){
                    el.remove()
                }
                console.log(323223)
                console.log(id)
            })
        }).trigger('change');
        $('#dls').on('select2:select', function(e) {
            // $(document.body).on("change","#parts",function(e){

            let parts=$('#dls').val()
            let last=e.params.data.id
            var obj_a = {};
            obj_a[last]= $('#dls option[value='+last+']').text();

            // parts.forEach(function(val, i) {
            //    var text= $('#parts option[value='+val+']').text();
            //     obj_a[val] = text;
            //
            // });

            let ps=$('#dls_section')
            let id= ps.children().length
            // ps.append(
            // '<br>'
            // )
            ps.append(
                createNewDls({
                    obj_a,id,last
                })
            )
            // $('.attr_select2').select2({tags:true})
        });
        $(document).on('click', '.remove_r', function (event) {
            var el = $(this);
            var ids = el.data('ids');
            var val = el.data('val');
            var id = el.data('id');
            var cl = el.data('cl');
            $('#dls option[value='+val+']').prop("selected", false)     // deselect the option
                .parent().trigger("change");
            $('#' + 'dls-'+val).remove();
            $('.' + cl).attr('checked', false);
            $('.' + cl).prop('checked', false); // $('input[name='+id+']').prop('checked', false);
        });
        // if ($('#parts').length){
        //     let parts=$('#parts').val()
        //     var obj_a = {};
        //     parts.forEach(function(val, i) {
        //         var text= $('#parts option[value='+val+']').text();
        //         obj_a[val] = text;
        //
        //     });
        //     let ps=$('#part_section')
        //     let id= ps.children().length
        //     ps.html(
        //         '<br>'
        //     )
        //     ps.html(
        //         createNewDls({
        //             obj_a ,
        //             id
        //         })
        //     )
        //
        // }

    </script>
    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/report/stock.blade.php ENDPATH**/ ?>