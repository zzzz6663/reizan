<option   value="">قطعه را انتخاب کنید </option>
<?php $__currentLoopData = $product->parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($parts->id); ?>"><?php echo e($parts->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\laravelProject\raizan\resources\views/admin/get_part.blade.php ENDPATH**/ ?>