<?php if($paginator->lastPage() > 1): ?>


<ul class="pagination ms-auto">
    <li class="page-item ">
        <?php if($paginator->currentPage() > 1): ?>
      <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>" tabindex="-1" aria-disabled="true">
        <!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg>

        قبلی
      </a>
      <?php endif; ?>
    </li>

    <?php
 $link_limit = 12;
    ?>
    <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
    <?php
    $half_total_links = floor($link_limit / 2);
    $from = $paginator->currentPage() - $half_total_links;
    $to = $paginator->currentPage() + $half_total_links;
    if ($paginator->currentPage() < $half_total_links) {
       $to += $half_total_links - $paginator->currentPage();
    }
    if ($paginator->lastPage() - $paginator->currentPage() < $half_total_links) {
        $from -= $half_total_links - ($paginator->lastPage() - $paginator->currentPage()) - 1;
    }
    ?>
    <?php if($from < $i && $i < $to): ?>
        <li class="page-item  <?php echo e(($paginator->currentPage() == $i) ? ' active' : ''); ?>">
            <a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
        </li>
    <?php endif; ?>
<?php endfor; ?>
    

    <?php if($paginator->currentPage() <$paginator->lastPage()): ?>

      <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>">
        بعدی <!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg>

      </a>
    <?php endif; ?>

    </li>
  </ul>
  <hr>

    <span style="margin-right: 20px">صفحه
        <?php echo e($paginator->currentPage()); ?>

                        از
                       <?php echo e($paginator->lastPage()); ?>

         </span>
    






            

        
    

<?php endif; ?>
<?php /**PATH G:\laravelProject\reizan\resources\views/admin/pagination.blade.php ENDPATH**/ ?>