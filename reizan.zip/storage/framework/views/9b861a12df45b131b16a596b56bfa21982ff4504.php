<?php $__env->startComponent('admin.section.content',['title'=>' مدیریت بارکد']); ?>
<?php $__env->slot('bread'); ?>
<li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
<li class="breadcrumb-item">مدیریت بارکد</li>
<?php $__env->endSlot(); ?>


<div class="row">
    <div class="col-md-12">
        <div class="row">


            <div class="col-md-6">


                <div class="card">
                    <div class="card-header no-border">
                        <div class="d-flex justify-content-between">
                            <h3 class="card-title">
                                اقدامات بارکد
                            </h3>
                            <a href="javascript:void(0);"> <?php echo e($barcode->code); ?></a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="d-flex">
                            <p class="d-flex flex-column">
                                <span class="text-bold text-lg"> آخرین وضعیت </span>
                                <span>
                                    <?php if(!$barcode->customer): ?>
                                    فروش نرفته
                                    -داخل انبار
                                    <?php else: ?>
                                    <?php switch($barcode->store):
                                    case (null): ?>
                                    تعیین نشده
                                    <?php break; ?>
                                    <?php case (1): ?>
                                    داخل انبار
                                    <?php break; ?>
                                    <?php case (0): ?>
                                    خارج
                                    <?php break; ?>
                                    <?php endswitch; ?>
                                    <?php endif; ?>
                                </span>
                            </p>
                            
                        </div>
                        <?php
                        $repair =$barcode->repairs()->latest()->first();
                        ?>

                        <?php if(!$barcode->customer): ?>
                        <a href="<?php echo e(route('barcode.edit',$barcode->id)); ?>" class="btn btn-success">فروش</a>
                        <?php else: ?>

                          <?php if(($barcode->last_id) && $barcode->last_id != auth()->user()->id): ?>
                        
                          <a href="<?php echo e(route('transfer.create',['barcode'=>$barcode->id])); ?>" class="btn btn-danger">انتقال</a>
                           <?php endif; ?>
                        <?php switch($barcode->store):
                        case (null): ?>
                        <?php if($repair): ?>
                        <a href="<?php echo e(route('repair.edit',$repair->id)); ?>" class="btn btn-success">  تحویل</a>
                        <?php else: ?>
                        <a href="<?php echo e(route('repair.index',['code'=>$barcode->id])); ?>" class="btn btn-success">ثبت خرابی</a>
                        <?php endif; ?>
                        <?php break; ?>

                        <?php case (1): ?>
                        <?php if(  $repair): ?>
                        <a href="<?php echo e(route('repair.edit',$repair->id)); ?>" class="btn btn-success">  تحویل</a>
                        <?php endif; ?>
                        <?php break; ?>

                        <?php case (0): ?>
                        <a href="<?php echo e(route('repair.index',['code'=>$barcode->id])); ?>" class="btn btn-success">ثبت خرابی</a>
                        <?php break; ?>
                        <?php endswitch; ?>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <?php echo $__env->make('admin.barcode.record',['barcode'=>$barcode], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\reizan\resources\views/admin/barcode/scan.blade.php ENDPATH**/ ?>