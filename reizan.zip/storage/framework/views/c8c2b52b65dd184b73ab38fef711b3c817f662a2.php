<?php $__env->startComponent('admin.section.content',['title'=>'  مشاهده بارکد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">مشاهده  جزئیات  بارکد</li>
    <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h5 class="card-title">  جزئیات   بارکد
                            <?php echo e($barcode->code); ?>

                            </h5>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                               محصول:
                                       </span>
                                        <?php if(isset($barcode->product)): ?>
                                        <?php echo e($barcode->product->name); ?>

                                        <?php endif; ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                               مشتری:
                                       </span>
                                        <?php if($barcode->customer): ?>
                                        <?php echo e($barcode->customer->name); ?>

                                        <?php echo e($barcode->customer->family); ?>

                                            <?php endif; ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                            تخفیف
                                       </span>
                                        <?php echo e($barcode->discount); ?>%
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                            وضعیت
                                       </span>
                                       <span class="text-<?php echo e($barcode->cleared==1?'success   ':'danger   '); ?> ">
                                            <?php echo e($barcode->cleared==1?'تسویه شده':'تسویه نشده'); ?>

                                       </span>
                                    </h5>
                                </div>

                                <div class="col-3">
                                    <h5>
                                       <span class="text-primary">
                                            تاریخ تولید:
                                       </span>
                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)->format('h-m-Y')); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                                   تاریخ خروج:

                                       </span>
                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)->format('h-m-Y')); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                           ورژن:
                                       </span>

                                       <?php echo e(implode(', ',$barcode->versions->pluck('name')->toArray())); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                          رنگ:
                                       </span>

                                        <?php echo e(implode(', ',$barcode->colores->pluck('name')->toArray())); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                          گارانتی:
                                       </span>

                                        <?php echo e($barcode->guaranty); ?>

                                        ماه
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                              مشتری:
                                       </span>

                                        <?php if($barcode->customer): ?>

                                        <?php echo e($barcode->customer->name); ?>

                                        <?php echo e($barcode->customer->family); ?>

                                            <?php endif; ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                              استان:
                                       </span>
                                        <?php if($barcode->customer): ?>

                                        <?php echo e($barcode->customer->ostan->name); ?>

                                        <?php endif; ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                            مونتاژ:
                                       </span>
                                        <?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($operator->name); ?>

                                            <?php echo e($operator->family); ?> -
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-primary">
                                               توضیحات:
                                       </span>

                                        <?php echo e($barcode->info); ?>

                                    </h5>
                                </div>



                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <h5>
                                            <span class="text-primary">
                                             قطعات
                                       </span>
                                        <?php if(isset($barcode->product)): ?>
                                        <?php echo e(implode('-',$barcode->product->parts->pluck('name')->toArray()  )); ?>

                                        <?php endif; ?>
                                    </h5>
                                </div>
                            </div>










                             <div class="row">
                                 <div class="col-12">
                                     <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">برگشت</a>
                                 </div>
                             </div>
                        </div>


                    </div>



                    <div class="card card-secondary">
                        <div class="card-header">
                            <h3 class="card-title">     تاریخچه
                                <?php echo e($barcode->code); ?>

                            </h3>
                        </div>
                        <!-- /.card-header -->

                        <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>











                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <h1>
                                لیست خرابی ها
                            </h1>
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>نام </th>
                                    <th>همراه </th>
                                    <th>وضعیت </th>
                                    <th>اپراتور </th>
                                    <th>تاریخ </th>

                                    <th>اقدام </th>
                                </tr>
                                <?php $__currentLoopData = $barcode->repairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($repair->name); ?></td>
                                        <td><?php echo e($repair->tell); ?></td>
                                        <td><?php echo e(__('arr.'.$repair->status)); ?></td>
                                        <td>
                                            <?php if($repair->user): ?>
                                            <?php echo e($repair->user->name); ?>


                                            <?php echo e($repair->user->family); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($repair->created_at)); ?></td>
                                        <td>
                                            <a class="btn btn-outline-primary" href="<?php echo e(route('repair.edit',$repair->id)); ?>">ویرایش</a>
                                            
                                            <a class="btn btn-outline-danger" href="<?php echo e(route('repair.print.factor',$repair->id)); ?>">رسید ها</a>
                                            <a class="btn btn-outline-warning" href="<?php echo e(route('repair.ready.sms',$repair->id)); ?>">  ارسال پیامک مراجعه</a>
                                            <a class="btn btn-outline-success" href="<?php echo e(route('repair.deliver.sms',$repair->id)); ?>">  ارسال پیامک تحویل</a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->



                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/barcode/show.blade.php ENDPATH**/ ?>