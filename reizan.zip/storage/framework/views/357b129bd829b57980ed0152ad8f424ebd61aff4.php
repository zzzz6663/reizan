<?php $__env->startComponent('admin.section.content',['title'=>'لیست کاربران']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست کاربران</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست   اشخاص ها</h3>
                            <div class="card-tools">
                                <div class="btn-group-sm">
                                <a class="btn btn-info" href="<?php echo e(route('staff.create')); ?>">  کاربر جدید</a>
                                </div>
                            </div>
                            <div class="card-tools">

                            </div>
                        </div>-.

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody><tr>
                                    <th>شماره</th>
                                    <th>نام </th>
                                    <th>نام کاربری</th>
                                    <th>رمز عبور </th>
                                    <th>نوع کاربر</th>
                                    <th>  اقدام</th>
                                </tr>

                                <?php $__currentLoopData = \App\Models\User::whereIn('level',['admin','operator','accountant','qc','service'])->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($user->name); ?> <?php echo e($user->family); ?>   (<?php echo e($user->id); ?>) </td>
                                        <td><?php echo e($user->username); ?></td>
                                        <td><?php echo e(\Illuminate\Support\Facades\Crypt::decryptString($user->password)); ?></td>
                                        <td><?php echo e(__('arr.'.$user->level)); ?></td>
                                        <td><a class="btn  btn-outline-primary" href="<?php echo e(route('staff.edit',$user->id)); ?>">ویرایش</a>
                                            <form action="<?php echo e(route('staff.destroy',$user->id)); ?>" style="display: inline-block" method="post">
                                                <?php echo method_field('post'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" value="حذف" class="btn btn-danger">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
        <div class="col-md-12">


        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/staff/all.blade.php ENDPATH**/ ?>