<?php $__env->startComponent('admin.section.content',['title'=>'     مشاهده بار کد و ثبت خرابی']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">   مشاهده بار کد و ثبت خرابی


        </li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم  اطلاعات
                                <?php echo e($barcode->code); ?>

                            </h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">
                                 <h5>
                                       <span class="text-danger">
                                               محصول:
                                       </span>
                                          <?php if($barcode->product): ?>

                                     <?php echo e($barcode->product->name); ?>

                                     <?php endif; ?>
                                 </h5>
                                </div>

                                <div class="col-3">
                                    <h5>
                                       <span class="text-danger">
                                            تاریخ تولید:
                                       </span>
                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)->format('h-m-Y')); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-danger">
                                                   تاریخ خروج:

                                       </span>
                                      <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)->format('h-m-Y')); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-danger">
                                           ورژن:
                                       </span>
                                       <?php echo e(implode(', ',$barcode->versions->pluck('name')->toArray())); ?>


                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-danger">
                                          رنگ:
                                       </span>

                                        <?php echo e(implode(', ',$barcode->colores->pluck('name')->toArray())); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-danger">
                                              مشتری:
                                       </span>

                                        <?php echo e($barcode->customer->name); ?>

                                        <?php echo e($barcode->customer->family); ?>

                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-danger">
                                              اپراتور:
                                       </span>
                                        <?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($operator->name); ?>

                                            <?php echo e($operator->family); ?> -
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h5>
                                </div>
                                <div class="col-3">
                                    <h5>
                                            <span class="text-danger">
                                               توضیحات:
                                       </span>

                                        <?php echo e($barcode->info); ?>

                                    </h5>
                                </div>

                            </div>
                        </div>


                    </div>
                    <div class="card card-secondary">
                        <div class="card-header">
                            <h3 class="card-title">     تاریخچه
                                <?php echo e($barcode->code); ?>

                            </h3>
                        </div>
                        <!-- /.card-header -->

                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card-body">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <a href="<?php echo e(route('repair.index')); ?>" class="btn btn-secondary">برگشت</a>
                                        <a href="<?php echo e(route('repair.create',['barcode'=>$barcode->id])); ?>" class="btn btn-danger">ثبت خرابی جدید</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                             <h1>
                                 لیست خرابی ها
                             </h1>
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>نام </th>
                                    <th>همراه </th>
                                    <th>وضعیت </th>
                                    <th>اپراتور </th>
                                    <th>تاریخ </th>

                                    <th>اقدام </th>
                                </tr>
                                <?php $__currentLoopData = $barcode->repairs()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($repair->name); ?></td>
                                        <td><?php echo e($repair->tell); ?></td>
                                        <td><?php echo e(__('arr.'.$repair->status)); ?></td>
                                        <td>
                                            <?php if($repair->user): ?>
                                            <?php echo e($repair->user->name); ?>


                                            <?php echo e($repair->user->family); ?>

                                            <?php endif; ?>

                                        </td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($repair->created_at)); ?></td>

                                        <td>
                                            <a class="btn btn-outline-primary" href="<?php echo e(route('repair.edit',$repair->id)); ?>">ویرایش</a>

                                            <a class="btn btn-outline-danger" href="<?php echo e(route('repair.add.images',$repair->id)); ?>">  تصاویر</a>
                                            <a class="btn btn-outline-danger" href="<?php echo e(route('repair.print.factor',$repair->id)); ?>">رسید ها</a>
                                            <a class="btn btn-outline-warning" href="<?php echo e(route('repair.ready.sms',$repair->id)); ?>">  ارسال پیامک مراجعه</a>
                                            <a class="btn btn-outline-success" href="<?php echo e(route('repair.deliver.sms',$repair->id)); ?>">  ارسال پیامک تحویل</a>
                                            <form action="<?php echo e(route('repair.destroy',$repair->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <input type="submit" value="حذف" class="btn btn-danger">
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->



                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\reizan\resources\views/admin/repair/res.blade.php ENDPATH**/ ?>