<?php $__env->startComponent('admin.section.content',['title'=>'لیست خرابی ها']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست  خرابی ها</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">       بارکد</h3>





                            <div class="card-tools"  >
                                <form action="<?php echo e(route('repair.index')); ?>" method="get">
                                    <div class="input-group input-group-sm" style="width: 250px;">
                                        <?php echo method_field('get'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="text"  name="search" value="<?php echo e(request('search')); ?>" class="form-control float-right" placeholder=" جستجو بارکد">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody>
                                <tr>
                                    <th>شماره</th>
                                    <th>کد </th>
                                    <th>محصول </th>
                                    <th>تاریخ تولید </th>
                                    <th>تاریخ خروج </th>
                                    <th>  ورژن </th>
                                    <th>  رنگ </th>
                                    <th>  مشتری </th>
                                    <th>  اپراتور </th>
                                    <th>  توضیحات </th>
                                    <th>  اقدامات </th>
                                </tr>
                                <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($barcode->code); ?></td>

                                        <td><?php echo e($barcode->product->name); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->produce)); ?></td>
                                        <td><?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->deliver)); ?></td>
                                        <td><?php echo e(isset($barcode->color)?$barcode->color->name:'---'); ?></td>
                                        <td><?php echo e(isset($barcode->version)?$barcode->version->name:'---'); ?></td>
                                        <td><?php echo e(isset($barcode->customer)?$barcode->customer->name.' '.$barcode->customer->family:'---'); ?></td>
                                        <td><?php $__currentLoopData = $barcode->operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($operator->name); ?>

                                                <?php echo e($operator->family); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($barcode->info); ?></td>
                                        <td>
                                            <a class="btn btn-outline-primary" href="<?php echo e(request()->fullUrlWithQuery(['code'=>$barcode->id])); ?>">مشاهده</a>





                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/repair/all.blade.php ENDPATH**/ ?>