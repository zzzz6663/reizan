<?php $__env->startComponent('admin.section.content',['title'=>'  به روز رسانی  دسته بندی']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد  دسته بندی</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="card-body">
                        <div class="alert alert-danger alert-dismissible">
                            <h5><i class="icon fa fa-ban"></i> توجه!</h5>
                            چنانچه وضعیت در حالت ثبت اولیه باشد قابلیت ویرایش همه اطالاعات  وجود دارد
                            <br>
                            در وضعیت ثبت نهایی فقط نام تحویل گیرنده و تاریخ تحویل قابل ثبت می باشد
                            <br>
                            در وضعیت تحویل کالا هیچ اطلاعاتی قابل ویرایش نیست
                         </div>

                    </div>

                    <div class="card card-dark">
                        <div class="card-header">
                            <h3 class="card-title">  فرم  ثبت خرابی جدید برای بار کد
                                <?php echo e($barcode->code); ?>

                                ------------------
                                <span class="text- ">وضعیت</span>
                                <span class="text-danger"><?php echo e(__('arr.'.$repair->status)); ?></span>
                            </h3>
                        </div>
                        <!-- /.card-header -->
                    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- form start -->
                        <form role="form" action="<?php echo e(route('repair.update',$repair->id)); ?>" method="post"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="card card-success">
                                <div class="card-header">
                                    <h3 class="card-title">    اطلاعات اولیه     </h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="exampleInpustEmail1">    تاریخ ارجاع</label>
                                                    <h5>
                                                        <?php echo e(\Morilog\Jalali\Jalalian::now()); ?>

                                                    </h5>
                                                </div>
                                                <div class="form-group">
                                                    <label for="name">نام   کاربر</label>
                                                    <input type="text" name="name" value="<?php echo e(old('name',$repair->name)); ?>" class="form-control" id="name" placeholder="نام را وارد کنید">
                                                    <input type="text" name="barcode" hidden value="<?php echo e(request('barcode')); ?>" >

                                                </div>
                                                <div class="form-group">
                                                    <label for="tell">تلفن</label>
                                                    <input type="number" name="tell" value="<?php echo e(old('tell',$repair->tell)); ?>" class="form-control" id="tell" placeholder="تلفن را وارد کنید">
                                                </div>
                                                <div class="form-group">
                                                    <label for="shipping">کرایه حمل</label>
                                                    <input type="number" name="shipping" value="<?php echo e(old('shipping',$repair->shipping)); ?>" class="form-control" id="shipping" placeholder="کرایه حمل را وارد کنید">
                                                </div>
                                                <div class="form-group">
                                                    <label for="address">    آدرس</label>
                                                    <textarea name="address" id="address" class="form-control" cols="30" rows="5"><?php echo e(old('address',$repair->address)); ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label for="comment">    اظهارات مشتری</label>
                                                    <textarea name="comment" id="comment" class="form-control" cols="30" rows="5"><?php echo e(old('comment',$repair->comment)); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">

                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="exampleInpustEmail1">      وضعیت گارانتی </label>
                                                    <h5>
                                                        به مدت
                                                        <span class="text-primary"><?php echo e($barcode->product->guaranty); ?></span>
                                                        ماه

                                                        از
                                                        <span class="text-success">     <?php echo e(\Morilog\Jalali\Jalalian::forge($barcode->sell)->format('h-m-Y')); ?></span>
                                                        نا
                                                        <span class="text-danger">
                                                                                                    <?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::parse($barcode->sell)->addMonths($barcode->guaranty))->format('h-m-Y')); ?>


                                                </span>

                                                    </h5>
                                                </div>
                                                <div class="form-group">
                                                    <label for="img1">  انتخاب عکس
                                                        1
                                                    </label>
                                                    <input type="file" accept="image/*" name="img1"  class="form-control" id="img1" placeholder="عکس را  انتخاب کنید">
                                                    <img src="<?php echo e(asset('src/repair/'.$repair->img1)); ?>" width="200px" alt="">
                                                </div>
                                                <div class="form-group">
                                                    <label for="img2">   انتخاب عکس
                                                        2
                                                    </label>
                                                    <input type="file" accept="image/*" name="img2"  class="form-control" id="img2" placeholder="عکس را  انتخاب کنید">
                                                    <img src="<?php echo e(asset('src/repair/'.$repair->img2)); ?>" width="200px" alt="">

                                                </div>
                                                <div class="form-group">
                                                    <label for="img3">    انتخاب عکس
                                                        3
                                                    </label>
                                                    <input type="file" accept="image/*" name="img3"  class="form-control" id="img3" placeholder="عکس را  انتخاب کنید">
                                                    <img src="<?php echo e(asset('src/repair/'.$repair->img3)); ?>" width="200px" alt="">

                                                </div>
                                                <div class="form-group">
                                                    <label for="bar">  بار متصل به دستگاه</label>
                                                    <input type="text" name="bar" value="<?php echo e(old('bar',$repair->bar)); ?>" class="form-control" id="bar" placeholder=" بار   را وارد کنید">
                                                </div>
                                                <div class="form-group">
                                                    <label for="defect">      نقص دستگاه</label>
                                                    <input type="text" name="defect" value="<?php echo e(old('defect',$repair->defect)); ?>" class="form-control" id="defect" placeholder="نقص   را وارد کنید">
                                                </div>
                                                <div class="form-group">
                                                    <label for="report">گزارش اولیه    </label>
                                                    <textarea name="report" id="report" class="form-control" cols="30" rows="5"><?php echo e(old('report',$repair->report)); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card card-danger">
                                <div class="card-header">
                                    <h3 class="card-title">    آسیب ها     </h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" name="dewater" hidden  value="0"  >
                                                    <input type="checkbox" <?php echo e(old('dewater',$repair->dewater)=='1'?'checked':''); ?> name="dewater" id="dewater" class="form-check-inline"  value="1" >
                                                    <label class="form-check-inline" for="dewater">آبخوردگی
                                                    </label>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" name="dehit" hidden  value="0"  >
                                                    <input type="checkbox" <?php echo e(old('dehit',$repair->dehit)=='1'?'checked':''); ?> name="dehit" id="dehit" class="form-check-inline"  value="1" >
                                                    <label class="form-check-inline" for="dehit">ضربه خوردگی
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" name="debar" hidden  value="0"  >
                                                    <input type="checkbox" <?php echo e(old('debar',$repair->debar)=='1'?'checked':''); ?> name="debar" id="debar" class="form-check-inline"  value="1" >
                                                    <label class="form-check-inline" for="debar">اضافه بار
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" name="detemp" hidden  value="0"  >
                                                    <input type="checkbox" <?php echo e(old('detemp',$repair->detemp)=='1'?'checked':''); ?> name="detemp" id="detemp" class="form-check-inline"  value="1" >
                                                    <label class="form-check-inline" for="detemp">اضافه حرارت محیط
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" name="deopen" hidden  value="0"  >
                                                    <input type="checkbox" <?php echo e(old('deopen',$repair->deopen)=='1'?'checked':''); ?> name="deopen" id="deopen" class="form-check-inline"  value="1" >
                                                    <label class="form-check-inline" for="deopen">    باز شدن پلمپ
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <input type="checkbox" name="demulti" hidden  value="0"  >
                                                    <input type="checkbox" <?php echo e(old('demulti',$repair->demulti)=='1'?'checked':''); ?> name="demulti" id="demulti" class="form-check-inline"  value="1" >
                                                    <label class="form-check-inline" for="demulti">
                                                        دستکاری مولتی ترن
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card card-dark">
                                <div class="card-header">
                                    <h3 class="card-title">    تعمیرات     </h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6">

                                            <div class="card-body">














                                                <div class="form-group" id="part_section">
                                                <?php $__currentLoopData = old('part',$barcode->product->parts); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php ($status = DB::table('part_repair')->where('part_id', $pa['id'])->where('repair_id', $repair->id)->first()); ?>
                                                        <?php
                                                        $check=null;
                                                        if ($status && !old('part')){
                                                            $check=$status->status;
                                                        }else{
                                                            $check=    $pa['status'];
                                                        }
                                                        ?>





                                                        <div class="row  " id="parts-<?php echo e($loop->index); ?>">

                                                           <?php
//                                                        dump($repair->parts->contains($pa->id))

                                                            ?>
                                                            <div class="row">
                                                                <div class="col-lg-5">
                                                                    <label for="report">  نام قطعه    </label>
                                                                    <input type="text" name="part[<?php echo e($loop->index); ?>][name]" value="<?php echo e($pa['name']); ?>" readonly class="form-control" id="tell"  >
                                                                    <input type="text" name="part[<?php echo e($loop->index); ?>][id]" hidden value="<?php echo e($pa['id']); ?>" readonly    >

                                                                </div>
                                                                <div class="col-lg-5">
                                                                    <br>


                                                                    <div class="mt-4 form-group">
                                                                        <input type="text"  class=" " hidden name="part[<?php echo e($loop->index); ?>][status]"  value="">

                                                                        <input type="radio"  class="form-chessck-input minimal ch<?php echo e($loop->index); ?>" name="part[<?php echo e($loop->index); ?>][status]" <?php echo e($check=='guaranty'?'checked':''); ?> id="ga<?php echo e($loop->index); ?>" value="guaranty">
                                                                        <label class="mr-2" for="ga<?php echo e($loop->index); ?>"> گارانتی    </label>
                                                                        <input type="radio"  class=" ch<?php echo e($loop->index); ?>  mr-4"  name="part[<?php echo e($loop->index); ?>][status]" <?php echo e($check=='customer'?'checked':''); ?> id="cu<?php echo e($loop->index); ?>" value="customer">
                                                                        <label class="mr-2" for="cu<?php echo e($loop->index); ?>">    مشتری    </label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-2">
                                                                    <div class=" form-group">
                                                                        <span style="position:relative; top: 45px" class="btn btn-warning remove_r form-control" data-cl="ch<?php echo e($loop->index); ?>"  data-id="part[<?php echo e($loop->index); ?>][status]">حذف</span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">

                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="redate">  تاریخ تعمیر</label>
                                                    <input type="text" name="redate" value="<?php echo e(old('redate',$repair->redate)); ?>" class="form-control persian2" id="redate" placeholder="تاریخ تعمیر را وارد کنید">
                                                </div>
                                                <div class="form-group">
                                                    <label for="wage">  دستمزد  </label>
                                                    <input type="number" name="wage" value="<?php echo e(old('wage',$repair->wage)); ?>" class="form-control " id="wage" placeholder="دستمزد  را وارد کنید">
                                                </div>

                                                <div class="form-group">
                                                    <label for="explain">      توضیحات</label>
                                                    <textarea name="explain" id="explain" class="form-control" cols="30" rows="5"><?php echo e(old('explain',$repair->explain)); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card card-info">
                                <div class="card-header">
                                    <h3 class="card-title">     دیتا لاگر    </h3>
                                </div>

                                <div class="card-body">
                                    <?php $__currentLoopData = old('d',$barcode->product->dls); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php
                                        $dlss=$repair->loggers()->where('name',$dls['name'])->first();
                                        if ( $dlss && !old('d')){

                                                $dls['value']=$dlss['value'];
                                                $dls['info']=$dlss['info'];
                                        }
                                        ?>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="card-body">

                                                    <div class="form-group">
                                                        <label for="wage">  پارامتر  </label>
                                                        <input type="text" name="d[<?php echo e($loop->index); ?>][name]" value="<?php echo e($dls['name']); ?>" class="form-control " readonly id="wage" placeholder="نام  را وارد کنید">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <label for="wage">  مقدار  </label>
                                                        <input type="number" name="d[<?php echo e($loop->index); ?>][value]" value="<?php echo e($dls['value']); ?>" class="form-control " id="wage" placeholder="مقدار  را وارد کنید">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <label for="wage">  توضیحات  </label>
                                                        <input type="text" name="d[<?php echo e($loop->index); ?>][info]" value="<?php echo e($dls['info']); ?>" class="form-control " id="wage" placeholder="توضیحات  را وارد کنید">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>

                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">       تحویل    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="status">  <?php echo e($repair->status); ?>  وضعیت  </label>
                                                    <select name="status" class="form-control" id="status">
                                                        <?php if($repair->status=='submit'): ?>
                                                        <option <?php echo e(old('status',$repair->status=='submit'?'selected':'')); ?> value="submit">ثبت اولیه </option>

                                                        <option <?php echo e(old('status',$repair->status=='saves'?'selected':'')); ?> value="saves">ثبت نهایی</option>
                                                        <?php endif; ?>
                                                        <?php if($repair->status=='saves' || $repair->status=='delivered'): ?>
                                                                <option <?php echo e(old('status',$repair->status=='saves'?'selected':'')); ?> value="saves">ثبت نهایی</option>
                                                        <option <?php echo e(old('status',$repair->status=='delivered'?'selected':'')); ?> value="delivered">تحویل کالا</option>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="dename">نام   تحویل گیرنده</label>
                                                    <input type="text" name="dename" value="<?php echo e(old('dename',$repair->dename)); ?>" class="form-control" id="dename" placeholder="نام را وارد کنید">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="dedate">    تاریخ تحویل   </label>
                                                    <input type="text" name="dedate" value="<?php echo e(old('dedate',$repair->dedate)); ?>" class="form-control persian2" id="dedate" placeholder="نام را وارد کنید">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>







                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('repair.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php $__env->slot('script'); ?>
        <script>

            let createNewPart=({obj_a,id})=>{


                var list;
                var i=0;

                `
                ${

                    $.each(obj_a, function(index, value){



                        list +=  `
                             <div class="row  " id="parts-${i}">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="report">  نام قطعه    </label>
                                        <input type="text" name="part[${i}][name]" value="${value}" readonly class="form-control" id="tell"  >
                                        <input type="text" name="part[${i}][id]" hidden value="${index}" readonly    >

                                    </div>
                                    <div class="col-lg-6">
                                        <br>
                                        <div class="mt-4 form-group">
                                            <input type="radio"  class="form-chessck-input minimal " name="part[${i}][status]" id="ga{${i}}" value="guaranty">
                                            <label class="mr-2" for="ga{${i}}"> گارانتی    </label>
                                            <input type="radio"  class="   mr-4"  name="part[${i}][status]" id="cu{${i}}" value="customer">
                                            <label class="mr-2" for="cu{${i}}">    مشتری    </label>
                                        </div>
                                      </div>

                               </div>

                           </div>
                          `
                        i++;
                    })
                }

            `
                return list;
            }

            $(document.body).on("change","#parts",function(){
                let parts=$('#parts').val()
                var obj_a = {};
                parts.forEach(function(val, i) {
                    var text= $('#parts option[value='+val+']').text();
                    obj_a[val] = text;

                });
                let ps=$('#part_section')
                let id= ps.children().length
                ps.html(
                    '<br>'
                )
                ps.html(
                    createNewPart({
                        obj_a ,
                        id
                    })
                )
                // $('.attr_select2').select2({tags:true})
            });
            // if ($('#parts').length){
            //     let parts=$('#parts').val()
            //     var obj_a = {};
            //     parts.forEach(function(val, i) {
            //         var text= $('#parts option[value='+val+']').text();
            //         obj_a[val] = text;
            //
            //     });
            //     let ps=$('#part_section')
            //     let id= ps.children().length
            //     ps.html(
            //         '<br>'
            //     )
            //     ps.html(
            //         createNewPart({
            //             obj_a ,
            //             id
            //         })
            //     )
            //
            // }

        </script>
    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/repair/edit.blade.php ENDPATH**/ ?>
