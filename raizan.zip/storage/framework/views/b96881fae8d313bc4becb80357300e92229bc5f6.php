<?php $__env->startComponent('admin.section.content',['title'=>'  ایجاد خدمات']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد خدمات</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم خدمات</h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- form start -->
                        <form role="form" action="<?php echo e(route('service.store')); ?>" method="post" enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">نام خدمات</label>
                                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" id="exampleInputEmail1" placeholder="نام را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">  ویدئو خدمات</label>
                                    <input type="file" name="video"  class="form-control" accept="video/mp4" id="exampleInputEmail1" placeholder=" فایل خود را ارسال کنید ">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">توضیحات خدمات</label>
                                    <textarea name="content" id="" class="form-control" cols="30" rows="10"><?php echo e(old('content')); ?></textarea>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('service.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/service/create.blade.php ENDPATH**/ ?>