<?php $__env->startComponent('admin.section.content',['title'=>'  به روز رسانی  بارکد (حسابداری)']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد  بارکد (حسابداری)</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم ویرایش بارکد (حسابداری)
                            <?php echo e($barcode->code); ?>

                            </h3>
                        </div>
                        <!-- /.card-header -->
                      <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- form start -->
                        <form role="form" action="<?php echo e(route('admin.accountant.update', $barcode)); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                                <div class="form-group">
                                    <input type="text" name="url" value="<?php echo e(redirect()->back()->getTargetUrl()); ?>" hidden>
                                    <label for="discount">  درصد تخفیف  </label>
                                    <input type="number" name="discount" value="<?php echo e(old('discount',$barcode->discount)); ?>" class="form-control" id="discount" placeholder="درصد را وارد کنید">
                                </div>

                                <div class="form-group">
                                    <label for="cleared">    تصفیه شده  </label>
                                    <input type="text" hidden name="cleared" value="0">
                                    <input type="checkbox" name="cleared" value="1" <?php echo e(old('cleared',$barcode->cleared)==1?'checked':''); ?> class=" - " id="cleared" placeholder="نام را وارد کنید">
                                </div>
                            <!-- /.card-body -->
                                <div class="form-group">
                                    <label for="color">مشتری  </label>
                                    <select class="form-control" name="customer_id" id="customer">
                                        <option >یک مورد را انتخاب کنید</option>
                                        <?php $__currentLoopData = \App\Models\User::whereLevel('customer')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php echo e(old('customer_id',$barcode->customer_id)==$customer->id?'selected':''); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> <?php echo e($customer->family); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            <div class="form-group">
                                <label for="deliver">  تاریخ خروج</label>
                                <input type="text" name="deliver" value="<?php echo e(old('deliver',$barcode->deliver)); ?>" class="form-control persian" id="deliver" placeholder="تاریخ خروج را وارد کنید">
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">به روز رسانی</button>
                                <a class="btn btn-success" href="<?php echo e(session()->get('url',redirect()->route('admin.accountant.all'))); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/accountant/edit.blade.php ENDPATH**/ ?>