<?php $__env->startComponent('admin.section.content',['title'=>'لیست گالری']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست  گالری</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست    گالری</h3>
                            <div class="card-tools">
                                <div class="btn-group-sm">
                                    <a class="btn btn-info" href="<?php echo e(route('products.gallery.create',[ $product->id])); ?>">  تصویر  جدید</a>
                                </div>
                            </div>
                            <div class="card-tools">

                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <div class="row">
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="col-sm-2">
                                  <a href="<?php echo e(url($image['image'])); ?>">
                                      <img src="<?php echo e(url($image['image'])); ?>" width="200" height="100" class="img-fluid mb-2" alt="<?php echo e($image['alt']); ?>">
                                  </a>
                                  <form action="<?php echo e(route('products.gallery.destroy',[$product->id,$image->id])); ?>" id="image-<?php echo e($image->id); ?>" method="post">
                                      <?php echo method_field('delete'); ?>
                                      <?php echo csrf_field(); ?>
                                  </form>
                                  <a class="btn btn-primary" href="<?php echo e(route('products.gallery.edit',[$product->id,$image->id])); ?>">ویرایش</a>
                                  <a class="btn btn-danger" href="#" onclick="document.getElementById('image-<?php echo e($image->id); ?>').submit()">حذف</a>

                              </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/product/gallery/all.blade.php ENDPATH**/ ?>