                <?php $__env->startSection('main_body'); ?>
                    <?php echo $__env->make('home.section.header_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div id="main" class="rows">
                        <div class="container">

                            <div class="row">
                                <div class="col-lg-12">
                                    <div>
                                        <div class="main-title">

                                            <h3>
                                                <?php echo e($service->title); ?>

                                            </h3>
                                            <span class="after-title">
                                                <?php echo $service->content; ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>
                    </div>


                <?php $__env->stopSection(); ?>








<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\raizan\resources\views/home/services.blade.php ENDPATH**/ ?>