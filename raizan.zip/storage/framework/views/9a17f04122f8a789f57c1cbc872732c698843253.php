<?php $__env->startComponent('admin.section.content',['title'=>'  به روز رسانی  اسلایدر']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">ایجاد  اسلایدر</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  فرم  اسلایدر</h3>
                        </div>
                        <!-- /.card-header -->
                    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- form start -->
                        <form role="form" action="<?php echo e(route('slider.update',$slider->id)); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">نام اسلایدر</label>
                                    <input type="text" name="title" value="<?php echo e(old('title' ,$slider->title)); ?>" class="form-control" id="exampleInputEmail1" placeholder="نام را وارد کنید">
                                </div>
                                <div class="form-group">
                                    <label  >   تصویر شاخص </label>

                                    <div class="input-group">
                                        <input type="text" id="image_label" class="form-control" name="image" value="<?php echo e(old('image' ,$slider->image)); ?>"
                                               aria-label="Image" aria-describedby="button-image">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button" id="button-image">انتخاب</button>
                                        </div>
                                    </div>


                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">توضیحات اسلایدر</label>
                                    <textarea name="content" id="" class="form-control" cols="30" rows="10"><?php echo e(old('content' ,$slider->content)); ?></textarea>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                                <a class="btn btn-success" href="<?php echo e(route('slider.index')); ?>">برگشت</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {

            document.getElementById('button-image').addEventListener('click', (event) => {
                event.preventDefault();

                window.open('/file-manager/fm-button', 'fm', 'width=1400,height=800');
            });
        });

        // set file link
        function fmSetLink($url) {
            document.getElementById('image_label').value = $url;
        }
    </script>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\raizan\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>